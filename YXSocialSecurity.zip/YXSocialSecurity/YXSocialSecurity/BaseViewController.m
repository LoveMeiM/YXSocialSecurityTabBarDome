 //
//  ViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/3.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

extern NSInteger viewControllersCount;
@interface BaseViewController ()
{
    UIImageView *navBarHairlineImageView;
}
@end

@implementation BaseViewController

- (id)init{
    self = [super init];
    if (self) {
        self.enablePanGesture = YES;
       
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    DMLog(@"YYYYY :%lu",self.navigationController.viewControllers.count);

    if (self.navigationController.viewControllers.count>1) {
        self.hidesBottomBarWhenPushed = YES;
    }

    self.view.backgroundColor = [UIColor whiteColor];
     self.automaticallyAdjustsScrollViewInsets = NO;
    self.sc=[[UIScrollView alloc]init];
    self.sc.contentSize=CGRectMake(0, 0,self.view.frame.size.width,self.view.frame.size.height+1).size;
    self.sc.showsHorizontalScrollIndicator = NO;
    self.sc.showsVerticalScrollIndicator = NO;
    self.sc.backgroundColor = [UIColor whiteColor];
    self.sc.scrollEnabled=YES;
    [self.view addSubview:self.sc];
    self.sc.sd_layout.leftSpaceToView(self.view,0).topSpaceToView(self.view,0).rightSpaceToView(self.view,0).bottomSpaceToView(self.view,0);
    
    navBarHairlineImageView = [[MethodTool shareTool] findHairlineImageViewUnder:self.navigationController.navigationBar];
    navBarHairlineImageView.hidden = YES;
    
}

-(void)creatNavView :(NSString *)text
{
    
    UILabel *navLabel = [[MethodTool shareTool] creatLabelWithAttribute:text :BIG_FONT  :2 :[UIColor whiteColor]];;
    navLabel.frame = RECT(0, 0, 100, 15, 1);
    self.navigationItem.titleView = navLabel;
    [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];
}

- (void)creatLoginView
{
    UILabel *navLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"登录" :BIG_FONT  :2 :[UIColor whiteColor]];;
    navLabel.frame = RECT(0, 0, 100, 15, 1);
    self.navigationItem.titleView = navLabel;
    
    
    UIButton *leftButton = [[UIButton alloc]init];
    leftButton.frame = RECT(0, 20, 45, 50,1);
    UILabel *label = [[MethodTool shareTool]creatLabelWithAttribute:@"取消" :BIG_FONT :1 :[UIColor whiteColor]];
    label.frame = RECT(0, 10, 40, 31,1);
    [leftButton addSubview:label];
    leftButton.backgroundColor = [UIColor clearColor];
    [leftButton addTarget:self action:@selector(dissmissLoginV) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:leftButton];
    
    
    UIButton *rightB = [[UIButton alloc]init];
    rightB.frame = RECT(0, 20, 40, 23,1);
    rightB.backgroundColor = [UIColor clearColor];
    [rightB setTitle:@"注册" forState:UIControlStateNormal];
    [rightB.titleLabel setFont:[UIFont systemFontOfSize:MEDIUM_FONT]];
    [rightB.titleLabel setTextColor:[UIColor whiteColor]];
    rightB.layer.cornerRadius = Scale_X(3);
    rightB.layer.borderColor = [UIColor whiteColor].CGColor;
    rightB.layer.borderWidth = Scale_X(1);
    [rightB addTarget:self action:@selector(toRegister) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:rightB];
    self.view.backgroundColor = [UIColor whiteColor];
}


//首页
-(void)creatMainNavView :(NSString *)text
{
    
    UILabel *navLabel = [[MethodTool shareTool] creatLabelWithAttribute:text :BIG_FONT  :2 :[UIColor whiteColor]];;
    navLabel.frame = RECT(0, 0, 100, 15, 1);
    self.navigationItem.titleView = navLabel;
    
    
    UIButton *leftButton = [[UIButton alloc]init];
    leftButton.frame = RECT(0, 20, 45, 50,1);
    UIImageView *bgImageV = [[UIImageView alloc]init];
    bgImageV.frame = RECT(0, 10, 31, 31,1);
    bgImageV.image = [UIImage imageNamed:@"person"];
    [leftButton addSubview:bgImageV];
    leftButton.backgroundColor = [UIColor clearColor];
    [leftButton addTarget:self action:@selector(person) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:leftButton];
    

    UIButton *rightB = [[UIButton alloc]init];
    rightB.frame = RECT(0, 20, 45, 50,1);
    UIImageView *bgImageV1 = [[UIImageView alloc]init];
    bgImageV1.image = [UIImage imageNamed:@"message"];
    bgImageV1.frame = RECT(20, 10, 31, 31,1);
    [rightB addSubview:bgImageV1];
    rightB.backgroundColor = [UIColor clearColor];
    [rightB addTarget:self action:@selector(messageCenter) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:rightB];
    self.view.backgroundColor = [UIColor whiteColor];
    
}

//为查询页面而创建
-(void)creatNavForSearchView :(NSString *)text 
{
    
    UILabel *navLabel = [[MethodTool shareTool] creatLabelWithAttribute:text :BIG_FONT  :2 :[UIColor whiteColor]];;
    navLabel.frame = RECT(0, 0, 100, 15, 1);
    self.navigationItem.titleView = navLabel;
    
    
    UIButton *leftButton = [[UIButton alloc]init];
    leftButton.frame = RECT(0, 20, 45, 50,1);
    UILabel *leftLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"取消" :MEDIUM_FONT :1 :[UIColor whiteColor]];
    leftLabel.frame = RECT(0, 18, 50, 17,1);
    [leftButton addSubview:leftLabel];
    leftButton.backgroundColor = [UIColor clearColor];
    [leftButton addTarget:self action:@selector(cancelButtonEvent) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:leftButton];

    UIButton *rightB = [[UIButton alloc]init];
    rightB.frame = RECT(0, 20, 45, 50,1);
    UIImageView *bgImageV = [[UIImageView alloc]init];
    bgImageV.image = [UIImage imageNamed:@"goto"];
    bgImageV.frame = RECT(23, 15, 20, 20,1);
    [rightB addSubview:bgImageV];
    rightB.backgroundColor = [UIColor clearColor];
    [rightB addTarget:self action:@selector(search) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:rightB];
    
}
- (void)addNewRightNavItem
{
    UIButton *rightB = [[UIButton alloc]init];
    rightB.frame = RECT(0, 20, 45, 50,1);
    UILabel *leftLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"对比订单" :MEDIUM_FONT :2 :[UIColor whiteColor]];
    leftLabel.frame = RECT(1, 28, 80, 17,1);
    [rightB addSubview:leftLabel];
    rightB.backgroundColor = [UIColor clearColor];
    [rightB addTarget:self action:@selector(NewRightNavItemClick) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:rightB];

}
- (void)NewRightNavItemClick
{
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.hidden = NO;

    [MethodTool shareTool].viewForSVHUD = self.view;
    DMLog(@"Class :%@",NSStringFromClass(self.class));

}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillAppear:YES];
    [SVProgressHUD dismiss];
}


#pragma mark－－－－－－－－－－－－－－－－－－－button EVent－－－－－－－－－－－－－－－－

-(void)cancelButtonEvent
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)search
{
    
}
- (void)person
{
    
}
- (void)messageCenter
{
    
}
- (void)dissmissLoginV
{
    
}
-(void)toRegister
{
    
}


@end
