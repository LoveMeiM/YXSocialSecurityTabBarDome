//
//  SocialSecurityPayViewController.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/29.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SocialSecurityPayViewController.h"
#import "SocailSecurityLoginForPayViewController.h"
#import "SocailSecurityPayOweViewController.h"


@interface SocialSecurityPayViewController ()

@end

@implementation SocialSecurityPayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"社保缴费"];
    self.sc.backgroundColor = litteGray;
    
    //白色的背景
    UIView *whileBg = [UIView new];
    [self.sc addSubview:whileBg];
    whileBg.backgroundColor = [UIColor whiteColor];
    whileBg.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc ,NavHeight).rightSpaceToView(self.sc,0).heightIs(Scale_Y(105));
    
    
    NSArray *textArray = @[@"新农村",@"城乡居保"];
    for (int i = 0; i<textArray.count; i++) {
        
        int for_X = i%2;
        int for_Y = i/2;
        
        UIImageView *imageV = [[MethodTool shareTool] creatImageWithAttribute:[NSString stringWithFormat:@"jiaofei%d",i]];
        imageV.userInteractionEnabled = YES;
        [self.sc addSubview:imageV];
        imageV.sd_layout.leftSpaceToView(self.sc,Scale_X(55)+WIDTH/2*for_X).topSpaceToView(self.sc,(Scale_Y(20+105*for_Y))).widthIs(Scale_X(46)).heightIs(Scale_Y(46));
        
        UILabel *textlabel = [[MethodTool shareTool]creatLabelWithAttribute:textArray[i] :MEDIUM_FONT :2 :blackC];
        [self.sc addSubview:textlabel];
        textlabel .sd_layout.centerXEqualToView(imageV).topSpaceToView(imageV,Scale_Y(6)).widthIs(Scale_X(100)).heightIs(Scale_Y(20));
        
        UIButton *button = [[MethodTool shareTool] creatButtonWithAttribute:@"" :10 :[UIColor clearColor] :[UIColor clearColor]];
        [self.sc addSubview:button];
        button.sd_layout.leftSpaceToView(self.sc,WIDTH/2*for_X).topSpaceToView(self.sc,(Scale_Y((105.5*for_Y)))).widthIs(WIDTH/3).heightIs(Scale_Y(105));
        button.tag = 200+i;
        [button addTarget:self action:@selector(clickToShow:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    //顶上的线
    UIView *lineV0 = [UIView new];
    [self.sc addSubview:lineV0];
    lineV0.backgroundColor = litteGray;
    lineV0.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc ,Scale_Y(0)).widthIs(WIDTH).heightIs(Scale_Y(1.5));
    
    //第一条线
    UIView *lineV = [UIView new];
    [self.sc addSubview:lineV];
    lineV.backgroundColor = litteGray;
    lineV.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc ,Scale_Y(105)).widthIs(WIDTH).heightIs(Scale_Y(1.5));
    
    //竖线
    UIView *lineV1 = [UIView new];
    [self.sc addSubview:lineV1];
    lineV1.backgroundColor = litteGray;
    lineV1.sd_layout.centerXEqualToView(self.sc).topSpaceToView(self.sc ,Scale_Y(0)).widthIs(Scale_X(1)).heightIs(Scale_Y(105));
    
}
- (void)clickToShow :(UIButton *)sender
{
    FOR_PUSH
    if (sender.tag == 200) {
        [self.navigationController pushViewController:[[SocailSecurityLoginForPayViewController alloc]init] animated:YES];
    }else{
        [self.navigationController pushViewController:[[SocailSecurityPayOweViewController alloc]init] animated:YES];
    }
    
    FOR_PUSH
}



@end
