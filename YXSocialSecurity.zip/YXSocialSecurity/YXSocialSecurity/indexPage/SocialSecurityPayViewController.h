//
//  SocialSecurityPayViewController.h
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/29.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface SocialSecurityPayViewController : BaseViewController

@end
