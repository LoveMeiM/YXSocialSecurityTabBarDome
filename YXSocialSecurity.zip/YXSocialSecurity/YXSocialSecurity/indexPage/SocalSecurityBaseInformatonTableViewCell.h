//
//  SocalSecurityBaseInformatonTableViewCell.h
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/29.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SocalSecurityBaseInformatonTableViewCell : UITableViewCell


@property(strong,nonatomic)UILabel *leftL;
@property(strong,nonatomic)UILabel *righyL;

@end
