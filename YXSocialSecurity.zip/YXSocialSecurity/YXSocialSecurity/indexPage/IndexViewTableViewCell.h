//
//  OrderPrograssDetailTableViewCell.h
//  BossTreasure
//
//  Created by liubaojian on 16/8/1.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IndexViewTableViewCell : UITableViewCell


@property(strong,nonatomic)UIImageView *imageV ;
@property(strong,nonatomic)UILabel *messageLabel;
@property(strong,nonatomic)UILabel *subMessageLabel;
@property(strong,nonatomic)UILabel *timeLabel;

@property(strong,nonatomic)NSDictionary *dataDic;

@end
