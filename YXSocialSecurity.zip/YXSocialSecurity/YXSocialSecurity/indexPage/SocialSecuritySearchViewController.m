//
//  SocialSecuritySearchViewController.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/28.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SocialSecuritySearchViewController.h"
#import "SocailSecurityBaseImformationViewController.h"
#import "SocalSecurityHistoryViewController.h"
#import "SocalSecurityOweInformationViewController.h"
#import "SocalSecurityPointAcountViewController.h"
#import "SocailSecurityPayOweViewController.h"
#import "SocalSecurityCardAcountController.h"
#import "SocalSecurityMedicalAccountViewController.h"
#import "SocalSecurityTreatmentSearchViewController.h"


@interface SocialSecuritySearchViewController ()

@end

@implementation SocialSecuritySearchViewController

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"社保查询"];
    self.sc.backgroundColor = litteGray;
    
    //白色的背景
    UIView *whileBg = [UIView new];
    [self.sc addSubview:whileBg];
    whileBg.backgroundColor = [UIColor whiteColor];
    whileBg.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc ,NavHeight).rightSpaceToView(self.sc,0).heightIs(Scale_Y(315));
    

    NSArray *textArray = @[@"基本信息",@"参保历史",@"欠费情况",@"医疗结算",@"待遇查询",@"选点记录",@"社保卡划拨"];
    for (int i = 0; i<textArray.count; i++) {
        
        int for_X = i%3;
        int for_Y = i/3;
        
        UIImageView *imageV = [[MethodTool shareTool] creatImageWithAttribute:[NSString stringWithFormat:@"secitySearch%d",i]];
        imageV.userInteractionEnabled = YES;
        [self.sc addSubview:imageV];
        imageV.sd_layout.leftSpaceToView(self.sc,Scale_X(28)+WIDTH/3*for_X).topSpaceToView(self.sc,(Scale_Y(10+105*for_Y))).widthIs(Scale_X(50)).heightIs(Scale_Y(51));
        
        UILabel *textlabel = [[MethodTool shareTool]creatLabelWithAttribute:textArray[i] :MEDIUM_FONT :2 :blackC];
        [self.sc addSubview:textlabel];
        textlabel .sd_layout.centerXEqualToView(imageV).topSpaceToView(imageV,Scale_Y(10)).widthIs(Scale_X(100)).heightIs(Scale_Y(20));
        
        UIButton *button = [[MethodTool shareTool] creatButtonWithAttribute:@"" :10 :[UIColor clearColor] :[UIColor clearColor]];
        [self.sc addSubview:button];
        button.sd_layout.leftSpaceToView(self.sc,WIDTH/3*for_X).topSpaceToView(self.sc,(Scale_Y((105.5*for_Y)))).widthIs(WIDTH/3).heightIs(Scale_Y(105));
        button.tag = 200+i;
        [button addTarget:self action:@selector(clickToShow:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    //顶上的线
    UIView *lineV0 = [UIView new];
    [self.sc addSubview:lineV0];
    lineV0.backgroundColor = litteGray;
    lineV0.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc ,Scale_Y(0)).widthIs(WIDTH).heightIs(Scale_Y(1.5));
    
    //第一条线
    UIView *lineV = [UIView new];
    [self.sc addSubview:lineV];
    lineV.backgroundColor = litteGray;
    lineV.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc ,Scale_Y(105)).widthIs(WIDTH).heightIs(Scale_Y(1.5));
    
    //第二条线
    UIView *lineV1 = [UIView new];
    [self.sc addSubview:lineV1];
    lineV1.backgroundColor = litteGray;
    lineV1.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc ,Scale_Y(210)).widthIs(WIDTH).heightIs(Scale_Y(1.5));
    
    //第三条线
    UIView *lineV2 = [UIView new];
    [self.sc addSubview:lineV2];
    lineV2.backgroundColor = litteGray;
    lineV2.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc ,Scale_Y(315)).widthIs(WIDTH/3).heightIs(Scale_Y(1.5));
    
    for (int i = 0; i<2; i++) {
        UIView *lineV = [UIView new];
        [self.sc addSubview:lineV];
        lineV.backgroundColor = litteGray;
        lineV.sd_layout.leftSpaceToView(self.sc,(WIDTH/3)*(i+1)).topSpaceToView(self.sc,NavHeight).widthIs(Scale_Y(1.5)).heightIs(i==1?Scale_Y(210):Scale_Y(315));
    }
    
}

- (void)clickToShow :(UIButton *)sender
{
    FOR_PUSH
    if (sender.tag == 200) {
        SocailSecurityBaseImformationViewController *subVC = [[SocailSecurityBaseImformationViewController alloc]init];
        [self.navigationController pushViewController:subVC animated:YES];
    }else if (sender.tag == 201){
        [self.navigationController pushViewController:[[SocalSecurityHistoryViewController alloc]init] animated:YES];
    }
    else if (sender.tag == 202){
        [self.navigationController pushViewController:[[SocalSecurityOweInformationViewController alloc]init] animated:YES];
    }
    else if (sender.tag == 203){
        [self.navigationController pushViewController:[[SocalSecurityMedicalAccountViewController alloc]init] animated:YES];
    }
    else if (sender.tag == 204){
        [self.navigationController pushViewController:[[SocalSecurityTreatmentSearchViewController alloc]init] animated:YES];
    }else if (sender.tag == 205){
        [self.navigationController pushViewController:[[SocalSecurityPointAcountViewController alloc]init] animated:YES];
    }
    else if (sender.tag == 206){
        [self.navigationController pushViewController:[[SocalSecurityCardAcountController alloc]init] animated:YES];
    }

}

@end
