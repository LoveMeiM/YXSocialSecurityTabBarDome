//
//  SocalSecurityBaseInformatonTableViewCell.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/29.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SocalSecurityBaseInformatonTableViewCell.h"

@implementation SocalSecurityBaseInformatonTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        
        self.contentView.backgroundColor = litteGray;
        
        UIView *bgView = [[UIView alloc]init];
        bgView.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:bgView];
        bgView.sd_layout.leftSpaceToView(self.contentView,Scale_X(10)).topSpaceToView(self.contentView,0).rightSpaceToView(self.contentView,Scale_X(10)).bottomSpaceToView(self.contentView,0);
        
    
        self.leftL= [[MethodTool shareTool] creatLabelWithAttribute:@"" :SMALL_FONT :1 :blackC];
        [bgView addSubview:self.leftL];
        self.leftL.sd_layout
        .leftSpaceToView(bgView,Scale_X(10))
        .centerYEqualToView(bgView)
        .widthIs(Scale_X(130))
        .heightIs(Scale_Y(15));
        
        
        self.righyL  = [[MethodTool shareTool] creatLabelWithAttribute:@"" :SMALL_FONT :1 :GrayTextColor];
        [bgView addSubview:self.righyL];
        self.righyL.sd_layout
        .leftSpaceToView(self.leftL,Scale_X(0))
        .centerYEqualToView(bgView)
        .rightSpaceToView(bgView,Scale_X(10))
        .heightIs(Scale_Y(15));
        
        
        //底部的细线
        UIView *lineV = [UIView new];
        [bgView addSubview:lineV];
        lineV.backgroundColor = ViewlineColor;
        lineV.sd_layout
        .leftSpaceToView(bgView,Scale_X(0))
        .bottomSpaceToView(bgView,Scale_Y(0))
        .rightSpaceToView(bgView,Scale_X(0))
        .heightIs(Scale_Y(1));
        
    }
    return self;
}

@end
