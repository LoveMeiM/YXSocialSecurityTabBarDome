//
//  IndexViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/3.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "IndexViewController.h"
#import "IndexViewTableViewCell.h"
#import "SocialSecuritySearchViewController.h"
#import "SocialSecurityPayViewController.h"

@interface IndexViewController ()
<UITableViewDelegate,UITableViewDataSource>
{
    
   UITableView *Tb;
    
}
@end

@implementation IndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"银信社保"];
    
    [self countEveryCellHeight];
    
    self.view.backgroundColor = litteGray;
    
    Tb = [[UITableView alloc] initWithFrame:CGRectMake(0, NavHeight, WIDTH, HEIGHT-NavHeight-50) style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor clearColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=YES;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    Tb.showsVerticalScrollIndicator = NO;
    [self.view addSubview:Tb];
    Tb.tableHeaderView = [self creatHeadView];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return Scale_Y(80);
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return Scale_Y(30);
}
- (UIView *)creatHeadView
{
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor = [UIColor whiteColor];
    view1.sd_layout.leftSpaceToView(Tb,20).topSpaceToView(Tb,10).rightSpaceToView(Tb,10).heightIs(Scale_Y(210));
    
    
    //头背景图片
    UIImageView *bgImaeV = [[MethodTool shareTool] creatImageWithAttribute:@"indexHead"];
    [view1 addSubview:bgImaeV];
    bgImaeV.sd_layout.leftSpaceToView(view1,0).topSpaceToView(view1,0).widthIs(Scale_X(320)).heightIs(Scale_Y(130));
    
    
    NSArray *titleArray = @[@"社保查询",@"社保缴费"];
    NSArray *titleArray1 = @[@"个人社保查询",@"社保轻松缴费"];
    for (int i = 0; i<titleArray.count;i++) {
        
        int for_x = i%2;
        int for_y = i/2;
        
       //图片
        UIImageView *bgImaeV = [[MethodTool shareTool] creatImageWithAttribute:[NSString stringWithFormat:@"index%d",i]];
        [view1 addSubview:bgImaeV];
        bgImaeV.sd_layout.leftSpaceToView(view1,Scale_X((15+for_x*160))).topSpaceToView(view1,Scale_Y((145+for_y*100))).widthIs(Scale_X(49)).heightIs(Scale_X(49));
        
        //标题
        UILabel *titlelabel  = [[MethodTool shareTool] creatLabelWithAttribute:[titleArray objectAtIndex:i] :MEDIUM_FONT :1 :blackC];
        [view1 addSubview:titlelabel];
        titlelabel.sd_layout
        .leftSpaceToView(bgImaeV,Scale_X((6)))
        .topSpaceToView(view1,Scale_Y((150+for_y*100)))
        .widthIs((WIDTH/3))
        .heightIs(Scale_Y(20));
        
        
        UILabel *subTitlelabel  = [[MethodTool shareTool] creatLabelWithAttribute:[titleArray1 objectAtIndex:i] :SMALL_FONT :1 :GrayTextColor];
        [view1 addSubview:subTitlelabel];
        subTitlelabel.sd_layout
        .leftEqualToView(titlelabel)
        .topSpaceToView(titlelabel,Scale_Y(2))
        .widthIs((WIDTH/3))
        .heightIs(Scale_Y(20));
        
        
        UIButton *but = [[MethodTool shareTool]creatButtonWithAttribute:@"" :11 :[UIColor clearColor] :[UIColor clearColor]];
        [view1 addSubview:but];
        but.tag = 200+i;
        but.sd_layout
        .leftSpaceToView(view1,((0+for_x*WIDTH/2)))
        .topSpaceToView(view1,Scale_Y((130+for_y*100)))
        .widthIs((WIDTH/2))
        .heightIs(Scale_Y(70));
        [but addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
        
    }

    UIView *line1=[[UIView alloc]init];
    line1.backgroundColor = litteGray;
    [view1 addSubview:line1];
    line1.sd_layout.centerXEqualToView(view1).topSpaceToView(view1,Scale_Y(130)).widthIs(Scale_X(2)).bottomSpaceToView(view1,0);
    
    
    UIView *line2=[[UIView alloc]init];
    line2.backgroundColor = litteGray;
    [view1 addSubview:line2];
    line2.sd_layout.leftSpaceToView(view1,0).bottomSpaceToView(view1,Scale_Y(0)).rightSpaceToView(view1,0).heightIs(Scale_Y(4));
    
    
    return view1;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor = [UIColor whiteColor];
    view1.sd_layout.leftSpaceToView(Tb,0).topSpaceToView(Tb,0).rightSpaceToView(Tb,0).heightIs(Scale_Y(30));
    

    UILabel *allGoodsNumberLabel = [[MethodTool shareTool] creatLabelWithAttribute: @"资讯"  :MEDIUM_FONT :1 :blackC];
    [view1 addSubview:allGoodsNumberLabel];
    allGoodsNumberLabel.sd_layout.leftSpaceToView(view1,Scale_X(10)).centerYEqualToView(view1).rightSpaceToView(view1,Scale_X(100)).heightIs(Scale_Y(20));

    
    //底部的细线
    UIView *lineV1 = [UIView new];
    [view1 addSubview:lineV1];
    lineV1.backgroundColor = litteGray;
    lineV1.sd_layout
    .leftSpaceToView(view1,Scale_X(0))
    .bottomSpaceToView(view1,Scale_Y(1))
    .rightSpaceToView(view1,Scale_X(0))
    .heightIs(Scale_Y(1));
    
    return view1;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    IndexViewTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[IndexViewTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.tag = indexPath.row;
    cell.imageV.image = [UIImage imageNamed:[NSString stringWithFormat:@"cell%ld",(long)indexPath.row]];
    //cell.dataDic = cellDataArray[indexPath.row];
    
    return cell;
}


// 分析数据
- (void)countEveryCellHeight
{
//    cellheightArray = [[NSMutableArray alloc]initWithCapacity:0];
//    cellDataArray = [[NSMutableArray alloc]initWithCapacity:0];
//    
//    NSDictionary *itemParam = self.dataDic[@"orderInfo"][@"itemParam"];
//    for (int i = 1; i<[itemParam allKeys].count+1; i++) {
//        NSString *cellDataKey = [NSString stringWithFormat:@"itemParam%d",i];
//        NSDictionary *oneCellData = itemParam[cellDataKey];
//        [cellDataArray addObject:oneCellData];
//        
//        CGFloat cellHeight = 0;
//        NSArray *keyA = @[@"color",@"size",@"spef",@"style"];
//        for (int i = 0; i<keyA.count; i++) {
//            if (![oneCellData[keyA[i]] isEqualToString:@"null"]) {
//                cellHeight += 40 ;
//            }
//        }
//        NSDictionary * workshop = oneCellData[@"workshop"];
//        cellHeight += [workshop allKeys].count*210;
//        [cellheightArray addObject:[NSNumber numberWithFloat:cellHeight]];
//    }
    
}


- (void)selectButton :(UIButton *)sender
{
    DMLog(@"but :%ld",(long)sender.tag);
    FOR_PUSH
    self.hidesBottomBarWhenPushed = YES;
    if (sender.tag == 200) {
        SocialSecuritySearchViewController *socialSecuritySearchVC = [[SocialSecuritySearchViewController alloc]init];
        [self.navigationController pushViewController:socialSecuritySearchVC animated:YES];
    }else{
        [self.navigationController pushViewController:[[SocialSecurityPayViewController alloc]init] animated:YES];
    }
    self.hidesBottomBarWhenPushed = NO;
}

@end
