//
//  SocialSecuritySearchViewController.h
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/28.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface SocialSecuritySearchViewController : BaseViewController

@end
