//
//  SocalSecurityHistoryViewController.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/30.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SocalSecurityHistoryViewController.h"
#import "HYSegmentedControl.h"
#import "InformationTableView.h"

@interface SocalSecurityHistoryViewController ()
{
    HYSegmentedControl *SegmentedControl;
    InformationTableView *informationTb;
    NSArray *leftArray1;
    NSArray *rightArray1;
}
@end

@implementation SocalSecurityHistoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"参保历史"];
    self.sc.backgroundColor = litteGray;
    
    SegmentedControl = [[HYSegmentedControl alloc]initWithOriginY:CGRectMake(0, NavHeight, WIDTH, Scale_Y(40))
                                                           Titles:@[@"账户信息", @"参保历史"]
                                                                 :blackC
                                                                 :MainNavColor
                                                                 :[UIColor whiteColor]
                                                         delegate:self] ;
    
    [self.view addSubview:SegmentedControl];
    
    
    
    
    leftArray1 = [[NSArray alloc]initWithObjects:@"所属机构",
                  @"社会保险登记证编号",
                  @"单位名称",
                  @"证书号码",
                  @"姓名",
                  @"性别",
                  @"名族",
                  @"籍贯",
                  @"文化程度",
                  @"出生日期",
                  @"婚姻情况",nil];
    
    rightArray1 = [[NSArray alloc]initWithObjects:@"惠州市社保局",
                   @"2423423423432423423",
                   @"惠州市一天科技有限公司",
                   @"1231242234355234234",
                   @"李晓红",
                   @"女",
                   @"汉",
                   @"广东省惠州市",
                   @"本科",
                   @"1985-02-09",
                   @"已婚",nil];
    
    
    informationTb = [[InformationTableView alloc] initWithFrame:CGRectMake(0, NavHeight+Scale_Y(50), WIDTH, HEIGHT-NavHeight-Scale_Y(50))];
    informationTb.leftArray = leftArray1;
    informationTb.rightArray = rightArray1;
    [self.view addSubview:informationTb];
    
}



#pragma mark－－－－－－－hySegmentedControl delegate－－－－－－－－－



- (void)hySegmentedControlSelectAtIndex:(NSInteger)index
{
    
}


@end
