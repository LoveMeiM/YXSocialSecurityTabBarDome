//
//  SocalSecurityPointAcountViewController.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/9.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SocalSecurityPointAcountViewController.h"
#import "InformationTableView.h"

@interface SocalSecurityPointAcountViewController ()
{
    InformationTableView *Tb;
    NSArray *leftArray1;
    NSArray *rightArray1;
}
@end

@implementation SocalSecurityPointAcountViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"选点纪录"];
    leftArray1 = [[NSArray alloc]initWithObjects:@"姓名",
                  @"证件号码",
                  @"选点医院",
                  @"经办时间",
                  @"开始年度",
                  @"开始年月",
                  @"终止年度",
                  @"终止年月",nil];
    
    rightArray1 = [[NSArray alloc]initWithObjects:@"张三",
                   @"41424142412414",
                   @"惠州市第三人民医院",
                   @"2016-09-09",
                   @"2016",
                   @"2016-03",
                   @"2018",
                   @"2018-04",nil];
    
    
    self.sc.backgroundColor = litteGray;
    
    Tb = [[InformationTableView alloc] initWithFrame:CGRectMake(0, Scale_Y(10), WIDTH, HEIGHT-NavHeight-20)];
    Tb.leftArray = leftArray1;
    Tb.rightArray = rightArray1;
    [self.sc addSubview:Tb];
    self.sc.contentSize = CGSizeMake(WIDTH, HEIGHT-Scale_Y(100)-NavHeight);
    
    
}

@end
