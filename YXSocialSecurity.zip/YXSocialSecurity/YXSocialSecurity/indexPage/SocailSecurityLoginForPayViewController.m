//
//  SocailSecurityLoginForPayViewController.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/31.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SocailSecurityLoginForPayViewController.h"

@interface SocailSecurityLoginForPayViewController ()
<UITextFieldDelegate>
{
    UITextField *TF[2];
}
@end

@implementation SocailSecurityLoginForPayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.sc.backgroundColor = litteGray;
    [super creatNavView:@"社保缴费"];
    [self initSubV];
    
}

- (void)initSubV
{
    //背景
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor = [UIColor whiteColor];
    [self.sc addSubview:view1];
    view1.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc,NavHeight).rightSpaceToView(self.sc,0).heightIs(Scale_Y(110));
    
    
    NSArray *titleArray  = @[@"参保号",@"密码"];
    NSArray *placeHoldArray  = @[@"请输入参保号",@"请输入密码"];
    
    for (int i = 0; i<2; i++) {
        
        
        UILabel *textlabel = [[MethodTool shareTool]creatLabelWithAttribute:titleArray[i] :MEDIUM_FONT :1 :blackC];
        [view1 addSubview:textlabel];
        textlabel .sd_layout.leftSpaceToView(view1,Scale_X(30)).topSpaceToView(view1,Scale_Y(20)+Scale_Y(55)*i).widthIs(Scale_X(50)).heightIs(Scale_Y(20));
        
        //竖线
        UIView *lineV = [UIView new];
        [view1 addSubview:lineV];
        lineV.backgroundColor = litteGray;
        lineV.sd_layout.leftSpaceToView(textlabel,Scale_X(20)).topEqualToView(textlabel).widthIs(Scale_X(0.8)).bottomEqualToView(textlabel);
        
        //底部的线
        UIView *bottowLine = [UIView new];
        [view1 addSubview:bottowLine];
        bottowLine.backgroundColor = litteGray;
        bottowLine.sd_layout.leftSpaceToView(view1,0).topSpaceToView(view1 ,(Scale_Y(55)*(i+1))).widthIs(WIDTH).heightIs(Scale_Y(1.5));
        
        
        TF[i] = [[MethodTool shareTool] creatTextFeild:placeHoldArray[i]];
        [view1 addSubview:TF[i]];
        TF[i].secureTextEntry = YES;
        TF[i].delegate = self;
        TF[i].sd_layout.leftSpaceToView(textlabel,Scale_X(50)).topSpaceToView(view1,Scale_Y(12)+Scale_Y(55)*i).widthIs(Scale_X(150)).heightIs(Scale_Y(40));
        
    }
    
    
    UIButton *button = [[MethodTool shareTool] creatButtonWithAttribute:@"登录" :MEDIUM_FONT :MainNavColor :[UIColor whiteColor]];
    [self.sc addSubview:button];
    button.sd_layout.leftSpaceToView(self.sc,Scale_X(15)).topSpaceToView(self.sc,Scale_Y(165)).rightSpaceToView(self.sc,Scale_X(15)).heightIs(Scale_Y(35));
    button.layer.cornerRadius = Scale_X(3);
    [button addTarget:self action:@selector(toLogin) forControlEvents:UIControlEventTouchUpInside];
}

 - (void)toLogin
{
    
}

@end
