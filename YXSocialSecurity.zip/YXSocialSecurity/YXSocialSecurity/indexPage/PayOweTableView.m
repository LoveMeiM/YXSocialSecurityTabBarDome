//
//  PayOweTableView.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/31.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PayOweTableView.h"

@implementation PayOweTableView

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return Scale_Y(70);
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor = litteGray;
    view1.sd_layout.leftSpaceToView(tableView,0).topSpaceToView(tableView,0).rightSpaceToView(tableView,0).heightIs(Scale_Y(80));
    
    UIButton *button = [[MethodTool shareTool] creatButtonWithAttribute:@"缴费" :MEDIUM_FONT :MainNavColor :[UIColor whiteColor]];
    [view1 addSubview:button];
    button.sd_layout.leftSpaceToView(view1,Scale_X(15)).topSpaceToView(view1,Scale_Y(25)).rightSpaceToView(view1,Scale_X(15)).heightIs(Scale_Y(40));
    button.layer.cornerRadius = Scale_X(3);
    [button addTarget:self action:@selector(payFor) forControlEvents:UIControlEventTouchUpInside];
    
    return view1;
}


- (void)payFor
{
    
}

@end
