//
//  SocalSecurityMedicalAccountViewController.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/9.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SocalSecurityMedicalAccountViewController.h"
#import "InformationTableView.h"

@interface SocalSecurityMedicalAccountViewController ()
{
    InformationTableView *Tb;
    NSArray *leftArray1;
    NSArray *rightArray1;
}
@end

@implementation SocalSecurityMedicalAccountViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"医疗结算"];
    leftArray1 = [[NSArray alloc]initWithObjects:@"入院日期",
                  @"出院日期",
                  @"结算日期",
                  @"就诊类型",
                  @"结算序号",
                  @"定点医疗机构",
                  @"统筹已报金额",
                  @"个人自费金额",
                  @"总费用",nil];
    
    rightArray1 = [[NSArray alloc]initWithObjects:@"2014-05-16",
                   @"2014-08-16",
                   @"2014-08-16",
                   @"外科",
                   @"201407211",
                   @"惠州市第三人民医院",
                   @"¥ 3567.53",
                   @"¥ 1167.53",
                   @"¥ 4647.53",nil];
    
    
    self.sc.backgroundColor = litteGray;
    
    Tb = [[InformationTableView alloc] initWithFrame:CGRectMake(0, Scale_Y(10), WIDTH, HEIGHT-NavHeight-20)];
    Tb.leftArray = leftArray1;
    Tb.rightArray = rightArray1;
    [self.sc addSubview:Tb];
    self.sc.contentSize = CGSizeMake(WIDTH, HEIGHT-Scale_Y(100)-NavHeight);
    
    
}

@end
