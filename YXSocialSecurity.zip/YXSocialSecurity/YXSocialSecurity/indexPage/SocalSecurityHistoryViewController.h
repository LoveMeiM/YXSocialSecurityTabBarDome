//
//  SocalSecurityHistoryViewController.h
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/30.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface SocalSecurityHistoryViewController : BaseViewController

@end
