//
//  InformationTableView.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/30.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "InformationTableView.h"
#import "SocalSecurityBaseInformatonTableViewCell.h"

@implementation InformationTableView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.delegate = self;
        self.dataSource = self;
        self.backgroundColor=[UIColor clearColor];
        self.separatorStyle = UITableViewCellSeparatorStyleNone;
        
    }
    return self;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40*NEWY;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return self.leftArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    SocalSecurityBaseInformatonTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[SocalSecurityBaseInformatonTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.tag = indexPath.row;
    cell.leftL.text = self.leftArray[indexPath.row];
    cell.righyL.text = self.rightArray[indexPath.row];
    if (cellRightTextColorChnage && indexPath.row==cellRightTextColorChnage) {
        cell.righyL.textColor = [UIColor colorWithRed:0.98 green:0.00 blue:0.00 alpha:1.00];
    }
    return cell;
}

- (void)setSomeCellRightTextColor :(NSInteger )cellIndex;
{
    cellRightTextColorChnage = cellIndex;
}

@end
