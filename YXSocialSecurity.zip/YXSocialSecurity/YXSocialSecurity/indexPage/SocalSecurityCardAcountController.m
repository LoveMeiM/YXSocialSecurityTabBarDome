//
//  SocalSecurityCardAcountController.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/9.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SocalSecurityCardAcountController.h"

#import "HYSegmentedControl.h"
#import "InformationTableView.h"

@interface SocalSecurityCardAcountController ()
{
    HYSegmentedControl *SegmentedControl;
    InformationTableView *informationTb;
    NSArray *leftArray1;
    NSArray *rightArray1;
}
@end

@implementation SocalSecurityCardAcountController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"社保卡划拨"];
    self.sc.backgroundColor = litteGray;
    
    SegmentedControl = [[HYSegmentedControl alloc]initWithOriginY:CGRectMake(0, NavHeight, WIDTH, Scale_Y(40))
                                                           Titles:@[@"划拨纪录", @"金额合计"]
                                                                 :blackC
                                                                 :MainNavColor
                                                                 :[UIColor whiteColor]
                                                         delegate:self] ;
    
    [self.view addSubview:SegmentedControl];
    
    
    
    
    leftArray1 = [[NSArray alloc]initWithObjects:@"参保险种",
                  @"缴费年月",
                  @"账户划入报盘情况",
                  @"配置金额",
                  @"配置日起",
                  @"报盘日期",nil];
    
    rightArray1 = [[NSArray alloc]initWithObjects:@"社会保险",
                   @"2014-06",
                   @"已划入",
                   @"¥ 70.98",
                   @"2014-05-21",
                   @"2014-05-25"
                   ,nil];
    
    
    informationTb = [[InformationTableView alloc] initWithFrame:CGRectMake(0, NavHeight+Scale_Y(50), WIDTH, HEIGHT-NavHeight-Scale_Y(50))];
    informationTb.leftArray = leftArray1;
    informationTb.rightArray = rightArray1;
    [self.view addSubview:informationTb];
    
}



#pragma mark－－－－－－－hySegmentedControl delegate－－－－－－－－－



- (void)hySegmentedControlSelectAtIndex:(NSInteger)index
{
    
}
@end
