//
//  InformationTableView.h
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/30.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InformationTableView : UITableView
<UITableViewDelegate,UITableViewDataSource>
{
    NSInteger cellRightTextColorChnage;
}

@property(retain,nonatomic)NSArray *leftArray;
@property(retain,nonatomic)NSArray *rightArray;

- (void)setSomeCellRightTextColor :(NSInteger )cellIndex;
@end
