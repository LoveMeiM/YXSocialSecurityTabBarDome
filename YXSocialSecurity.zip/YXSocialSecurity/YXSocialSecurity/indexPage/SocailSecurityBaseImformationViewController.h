//
//  SocailSecurityBaseImformationViewController.h
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/29.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface SocailSecurityBaseImformationViewController : BaseViewController

@end
