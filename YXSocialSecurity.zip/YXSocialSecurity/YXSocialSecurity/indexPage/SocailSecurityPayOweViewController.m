//
//  SocailSecurityPayOweViewController.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/31.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SocailSecurityPayOweViewController.h"
#import "SocalSecurityBaseInformatonTableViewCell.h"
#import "PayOweTableView.h"

@interface SocailSecurityPayOweViewController ()
{
    PayOweTableView *Tb;
    NSArray *leftArray1;
    NSArray *rightArray1;
}
@end

@implementation SocailSecurityPayOweViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"缴交欠费"];
    
    leftArray1 = [[NSArray alloc]initWithObjects:@"所属机构",
                  @"社会保险登记证编号",
                  @"单位名称",
                  @"证书号码",
                  @"姓名",
                  @"性别",
                  @"名族",
                  @"籍贯",
                  @"文化程度",
                  @"出生日期",
                  @"婚姻情况",nil];
    
    rightArray1 = [[NSArray alloc]initWithObjects:@"惠州市社保局",
                   @"2423423423432423423",
                   @"惠州市一天科技有限公司",
                   @"1231242234355234234",
                   @"李晓红",
                   @"女",
                   @"汉",
                   @"广东省惠州市",
                   @"本科",
                   @"1985-02-09",
                   @"已婚",nil];
    
    
    self.sc.backgroundColor = litteGray;
    
    Tb = [[PayOweTableView alloc] initWithFrame:CGRectMake(0, Scale_Y(10), WIDTH, HEIGHT-NavHeight-20)];
    Tb.leftArray = leftArray1;
    Tb.rightArray = rightArray1;
    [self.sc addSubview:Tb];
    self.sc.contentSize = CGSizeMake(WIDTH, HEIGHT-Scale_Y(40)-NavHeight);
    
    
}


@end
