//
//  OrderPrograssDetailTableViewCell.m
//  BossTreasure
//
//  Created by liubaojian on 16/8/1.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "IndexViewTableViewCell.h"

@implementation IndexViewTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        
        //图片
        self.imageV = [[MethodTool shareTool] creatImageWithAttribute:@""];
        [self.contentView addSubview:self.imageV];
        self.imageV.sd_layout
        .leftSpaceToView(self.contentView,Scale_X(10))
        .topSpaceToView(self.contentView,Scale_Y(10))
        .widthIs(Scale_X(85))
        .heightIs(Scale_Y(60));
        
        
        self.messageLabel= [[MethodTool shareTool] creatLabelWithAttribute:@"惠州市民中超九成菜价一项基本社保三成补充保险" :MEDIUM_FONT :1 :blackC];
        [self.contentView addSubview:self.messageLabel];
        self.messageLabel.numberOfLines = 0;
        self.messageLabel.sd_layout
        .leftSpaceToView(self.imageV,Scale_X(10))
        .topSpaceToView(self.contentView,Scale_Y(5))
        .rightSpaceToView(self.contentView,Scale_X(7))
        .heightIs(Scale_Y(45));
        
        
        self.subMessageLabel  = [[MethodTool shareTool] creatLabelWithAttribute:@"家园社区" :SMALL_FONT :1 :GrayTextColor];
        [self.contentView addSubview:self.subMessageLabel];
        self.subMessageLabel.sd_layout
        .leftSpaceToView(self.imageV,Scale_X(10))
        .bottomSpaceToView(self.contentView,Scale_Y(10))
        .widthIs(Scale_X(60))
        .heightIs(Scale_Y(20));
        
        
        
        self.timeLabel  = [[MethodTool shareTool] creatLabelWithAttribute:@"2016-07-25" :SMALL_FONT :1 :GrayTextColor];
        [self.contentView addSubview:self.timeLabel];
        self.timeLabel.sd_layout
        .leftSpaceToView(self.subMessageLabel,Scale_X(20))
        .bottomSpaceToView(self.contentView,Scale_Y(10))
        .widthIs(Scale_X(70))
        .heightIs(Scale_Y(20));
        
        
        //底部的细线
        UIView *lineV = [UIView new];
        [self.contentView addSubview:lineV];
        lineV.backgroundColor = litteGray;
        lineV.sd_layout
        .leftSpaceToView(self.contentView,Scale_X(0))
        .bottomSpaceToView(self.contentView,Scale_Y(2))
        .rightSpaceToView(self.contentView,Scale_X(0))
        .heightIs(Scale_Y(2));
        
    }
    return self;
}

- (void)setDataDic:(NSDictionary *)dataDic
{
    
//    for (UIView *subV in bgView.subviews) {
//        [subV removeFromSuperview];
//    }
//    NSDictionary *keyValueDic = [[NSDictionary alloc]initWithObjectsAndKeys:@"颜色",@"color",
//                                                                            @"尺码",@"size",
//                                                                            @"规格",@"spef",
//                                                                            @"花型",@"style",
//                                                                                nil];
//    NSArray *key = [keyValueDic allKeys];
//    NSMutableArray  *cellSubKeyArray = [[NSMutableArray alloc]initWithCapacity:0];
//    for (int i = 0; i<key.count; i++) {
//        if (![dataDic[key[i]] isEqualToString:@"null"]) {
//            [cellSubKeyArray addObject:key[i]];
//        }
//    }
//
//    
//    for (int i = 0; i<cellSubKeyArray.count; i++) {
//        //左侧标题
//        UILabel *titlelabel  = [[MethodTool shareTool] creatLabelWithAttribute:keyValueDic[[cellSubKeyArray objectAtIndex:i]] :MEDIUM_FONT :2 :GrayTextColor];
//        [bgView addSubview:titlelabel];
//        titlelabel.backgroundColor = RGB(232, 232, 232, 1);
//        titlelabel.sd_layout
//        .leftSpaceToView(bgView,Scale_X(0))
//        .topSpaceToView(bgView,Scale_Y((0+40*i)))
//        .widthIs(Scale_X(80))
//        .heightIs(Scale_Y(40));
//        
//        rightTextLablel[i]  = [[MethodTool shareTool] creatLabelWithAttribute:dataDic[[cellSubKeyArray objectAtIndex:i]] :MEDIUM_FONT :1 :blackC];
//        [bgView addSubview:rightTextLablel[i]];
//        rightTextLablel[i].sd_layout
//        .leftSpaceToView(titlelabel,Scale_X(10))
//        .topEqualToView(titlelabel)
//        .rightSpaceToView(bgView,Scale_X(0))
//        .heightIs(Scale_Y(40));
//        
//    }
//    
//    for (int i = 0; i<cellSubKeyArray.count; i++) {
//        //细线
//        UIView *lineV = [UIView new];
//        [bgView addSubview:lineV];
//        lineV.backgroundColor = ViewlineColor;
//        lineV.sd_layout
//        .leftSpaceToView(bgView,Scale_X(0))
//        .topSpaceToView(bgView,Scale_Y((40+40*i)))
//        .rightSpaceToView(bgView,Scale_X(0))
//        .heightIs(Scale_Y(1));
//    }
//    
//    NSDictionary * workshopDic = dataDic[@"workshop"];
//    
//    for (int i = 1; i<[workshopDic allKeys].count+1; i++) {
//        NSString *cellDataKey = [NSString stringWithFormat:@"workshop%d",i];
//        CarRoomView *carRoomV = [[CarRoomView alloc]initWithFrame:RECT(10, (cellSubKeyArray.count*40+10+187*(i-1)), 280, 180, 1) :workshopDic[cellDataKey]];
//        [bgView addSubview:carRoomV];
//    }
    
    
}

@end
