//
//  SocalSecurityTreatmentSearchViewController.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/9.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SocalSecurityTreatmentSearchViewController.h"
#import "InformationTableView.h"

@interface SocalSecurityTreatmentSearchViewController ()
{
    InformationTableView *Tb;
    NSArray *leftArray1;
    NSArray *rightArray1;
}
@end

@implementation SocalSecurityTreatmentSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"待遇查询"];
    leftArray1 = [[NSArray alloc]initWithObjects:@"操作",
                  @"审核年月",
                  @"待遇类型",
                  @"待遇金额",
                  @"发放方式",
                  @"单位名称",
                  @"社保登记证编码",nil];
    
    rightArray1 = [[NSArray alloc]initWithObjects:@"00002",
                   @"2014-07",
                   @"工资",
                   @"1200",
                   @"银行转帐",
                   @"惠州市天一科技有限公司",
                   @"453315235",nil];
    
    
    self.sc.backgroundColor = litteGray;
    
    Tb = [[InformationTableView alloc] initWithFrame:CGRectMake(0, Scale_Y(10), WIDTH, HEIGHT-NavHeight-20)];
    Tb.leftArray = leftArray1;
    Tb.rightArray = rightArray1;
    [self.sc addSubview:Tb];
    self.sc.contentSize = CGSizeMake(WIDTH, HEIGHT-Scale_Y(100)-NavHeight);
    
    
}


@end
