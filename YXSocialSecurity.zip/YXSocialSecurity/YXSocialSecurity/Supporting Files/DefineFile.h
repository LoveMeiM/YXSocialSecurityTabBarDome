

#define HEIGHT                   [UIScreen mainScreen].bounds.size.height
#define WIDTH                    [UIScreen mainScreen].bounds.size.width
#define NEWX                     [UIScreen mainScreen].bounds.size.width/320
#define NEWY                     [UIScreen mainScreen].bounds.size.height/568
#define RECT(a,b,c,d,e)          CGRectMake(a*NEWX, e==0?b:b*NEWY, c*NEWX, d*NEWY)
#define Scale_X(a)               (a*NEWX)
#define Scale_Y(a)               (a*NEWY)
#define NavHeight                0



#define SYSTEMIOS7  ([[[UIDevice currentDevice]systemVersion]floatValue]>=7?YES:NO)
#define IfDebug true

//http://121.43.101.138/weixin/orderDetail.json?fid=224
//#define ServerUrl @"http://www.tgrass.com/phone/"
//#define ServerUrl @"http://wifi.tgrass.com/app/"
#define ServerUrl                @"http://www.nhfmall.com:80/app/kernel.json?data="
//#define RequestUrl             @"http://app.tuorong-china.cn:8080/gx.deplay/app/kernel.json"//后台通用请求接口
#define UPImageURL               @"http://www.nhfmall.com/gx.fm//FileUpload"//图片上传接口
#define ShowImageURL             @"http://121.43.101.138:85/"//图片显示接口
#define ShowGoodsURL             @"http://www.nhfmall.com/app/appMerShow.json?"//图片商品详情


// 判断硬件类型
#define iPhone4 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 960), [[UIScreen mainScreen] currentMode].size) : NO)
#define iPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)
#define iPhone6Plus ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(414, 736), [[UIScreen mainScreen] currentMode].size) : NO)

#define SYSTEMIOS7  ([[[UIDevice currentDevice]systemVersion]floatValue]>=7?YES:NO)
#define current_SYSTEMIOS  ([[[UIDevice currentDevice]systemVersion]floatValue])
 
#define DATE_CURRENT ([NSDate date])
#define TimeOut 300



//*************************************** GEXUN ***********************************************

#define NEWSTITLECOLOR ([UIColor colorWithRed:64/255.0 green:56/255.0 blue:53/255.0 alpha:1.0f])
#define NEWSCONTEXTCOLOR ([UIColor colorWithRed:190/255.0 green:190/255.0 blue:190/255.0 alpha:1.0f])
#define blackC ([UIColor colorWithRed:70/255.0 green:70/255.0 blue:70/255.0 alpha:1.0f])
#define GrayTextColor  ([UIColor colorWithRed:160/255.0 green:160/255.0 blue:160/255.0 alpha:1.0f])
#define ViewlineColor ([UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1.00])
#define REDCOLOR ([UIColor colorWithRed:242/255.0 green:74/255.0 blue:81/255.0 alpha:1.0f])
#define ORANGE_COLOR ([UIColor colorWithRed:252/255.0 green:133/255.0 blue:37/255.0 alpha:1.0f])
#define LikeBlackColor    RGB(40, 40, 40, 1)
/**
 *
 
 */
//导航颜色
#define MainNavColor ([UIColor colorWithRed:19/255.0 green:125/255.0 blue:192/255.0 alpha:1.0f])
#define litteGray ([UIColor colorWithRed:246/255.0 green:246/255.0 blue:246/255.0 alpha:1.0f])
#define blueGreenColor ([UIColor colorWithRed:35/255.0 green:196/255.0 blue:187/255.0 alpha:1.0f])

#define RGB(a,b,c,d)  [UIColor  colorWithRed:(a/255.0) green:(b/255.0) blue:(c/255.0) alpha:(d)]
#define theDelegate ((AppDelegate *)[[UIApplication sharedApplication] delegate])

#define showMessage(a)   [SVProgressHUD showInfoWithStatus:a maskType:SVProgressHUDMaskTypeGradient];
#define showSuccessMessage(a)  [SVProgressHUD showSuccessWithStatus:a maskType:SVProgressHUDMaskTypeGradient];

#define kUseScreenShotGesture 1
#define Success  [[[MethodTool shareTool] cleanData:dataDic[@"status"]]isEqualToString:@"1"]
#define ShowHUD  [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeGradient];
#define DismissHUD  [SVProgressHUD dismiss];

#define HttpHead  [NSString stringWithFormat:@"http:/"]


//***********************************************************************************************

#define BIG_FONT    18
#define MEDIUM_FONT 14
#define SMALL_FONT  12
#define FOR_PUSH   self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStyleBordered target:nil action:nil];

//***********************************************************************************************

//由角度获取弧度 有弧度获取角度    M_PI  是一派
#define degreesToRadian(x) (M_PI * (x) / 180.0)
#define radianToDegrees(radian) (radian*180.0)/(M_PI)

