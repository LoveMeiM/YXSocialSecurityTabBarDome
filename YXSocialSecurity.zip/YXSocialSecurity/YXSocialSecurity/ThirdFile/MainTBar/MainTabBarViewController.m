//
//  MainTabVC.m
//  Boss
//
//  Created by 孙昕 on 15/11/24.
//  Copyright © 2015年 孙昕. All rights reserved.
//

#import "MainTabBarViewController.h"
#import "IndexViewController.h"
#import "MedicalViewController.h"
#import "PersonViewController.h"

@interface MainTabBarViewController ()<UITabBarControllerDelegate,UINavigationControllerDelegate>
{
 
}
@end

@implementation MainTabBarViewController

-(instancetype)init
{
    if(self=[super init])
    {
        
        IndexViewController *vc1=[[IndexViewController alloc] init];
        vc1.tabBarItem.title=@"社保";
        vc1.tabBarItem.image=[[UIImage imageNamed:@"tabBar0n"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        vc1.tabBarItem.selectedImage=[[UIImage imageNamed:@"tabBar0l"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        
        MedicalViewController *vc2=[[MedicalViewController alloc] init];
        vc2.tabBarItem.title=@"医疗";
        vc2.tabBarItem.image=[[UIImage imageNamed:@"tabBar1n"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        vc2.tabBarItem.selectedImage=[[UIImage imageNamed:@"tabBar1l"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        
        PersonViewController *vc4=[[PersonViewController alloc] init];
        vc4.tabBarItem.title=@"我";
        vc4.tabBarItem.image=[[UIImage imageNamed:@"tabBar2n"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        vc4.tabBarItem.selectedImage=[[UIImage imageNamed:@"tabBar2l"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        
        
        
        
        UINavigationController *nav1=[[UINavigationController alloc] initWithRootViewController:vc1];
        UINavigationController *nav2=[[UINavigationController alloc] initWithRootViewController:vc2];
        UINavigationController *nav4=[[UINavigationController alloc] initWithRootViewController:vc4];
        self.viewControllers=@[nav1,nav2,nav4];
        
        
        [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor grayColor], NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
        [[UITabBarItem appearance] setTitleTextAttributes:  [NSDictionary dictionaryWithObjectsAndKeys:MainNavColor ,NSForegroundColorAttributeName, nil]forState:UIControlStateSelected];
        self.delegate=self;

       
        UIImageView  *navBarHairlineImageView = [[MethodTool shareTool] findHairlineImageViewUnder:self.tabBar];
        navBarHairlineImageView.hidden = YES;
        
        [self.tabBar setBackgroundImage:[[MethodTool shareTool]imageWithColor:[UIColor whiteColor] size:CGSizeMake(WIDTH, 49)]];
        [self.tabBar setShadowImage:[[MethodTool shareTool]imageWithColor:ViewlineColor size:CGSizeMake(WIDTH, 0.5)]];
        self.tabBar.barTintColor = [UIColor whiteColor];
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
}


//
//- (id <UIViewControllerAnimatedTransitioning>)tabBarController:(UITabBarController *)tabBarController
//            animationControllerForTransitionFromViewController:(UIViewController *)fromVC
//                                              toViewController:(UIViewController *)toVC  NS_AVAILABLE_IOS(7_0);
//{
//    
//    
//    return ani;
//    
//}


@end
