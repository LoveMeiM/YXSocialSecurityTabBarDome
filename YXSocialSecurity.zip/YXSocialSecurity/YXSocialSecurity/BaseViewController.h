//
//  ViewController.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/3.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController
<UIGestureRecognizerDelegate>

@property(retain,nonatomic)UIScrollView *sc;
@property (nonatomic, assign) BOOL enablePanGesture;//是否支持拖动pop手势，默认yes,支持手势


-(void)creatNavView :(NSString *)text;
//为查询页面而创建
-(void)creatNavForSearchView :(NSString *)text ;
- (void)addNewRightNavItem;
//首页
-(void)creatMainNavView :(NSString *)text;

//为登录而来
- (void)creatLoginView;

@end

