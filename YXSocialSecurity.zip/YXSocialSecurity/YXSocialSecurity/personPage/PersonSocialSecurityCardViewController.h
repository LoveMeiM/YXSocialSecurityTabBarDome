//
//  PersonSocialSecurityCardViewController.h
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/12.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface PersonSocialSecurityCardViewController : BaseViewController

@end
