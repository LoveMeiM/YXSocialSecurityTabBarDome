//
//  PersonView.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/16.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PersonView.h"
#import "PersonTableViewCell.h"

@implementation PersonView

- (instancetype)init
{
    self = [super init];
    if (self) {
    }
    return self;
}

- (void)initSubVWithSuperView :(UIView *)superV;
{
    cellLeftTextArray = [[NSArray alloc]initWithObjects:@"",@"手机号码",@"诊疗卡",@"社保卡",@"支付记录",@"消息中心",@"我的收藏",@"设置", nil];
    
    [superV addSubview:self];
    self.sd_layout.leftSpaceToView(superV,0).topSpaceToView(superV,0).rightSpaceToView(superV,0).bottomSpaceToView(superV,0);
    self.backgroundColor = litteGray;
    
    Tb = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor clearColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=YES;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self addSubview:Tb];
    Tb.sd_layout.leftSpaceToView(self,0).topSpaceToView(self,NavHeight).rightSpaceToView(self,0).bottomSpaceToView(self,0);

    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        return Scale_Y(85);
    }else{
        return Scale_Y(48);
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return cellLeftTextArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    PersonTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[PersonTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UIImageView *imageV = [[MethodTool shareTool]  creatImageWithAttribute:@"personArrow"];
        imageV.bounds = CGRectMake(0, 0, 14, 14);
        cell.accessoryView = imageV;
    }
    if (indexPath.row == 0) {
        cell.imageV.bounds = RECT(20, 7, 70, 70, 1);
        cell.imageV.image = [UIImage imageNamed:@"testPersonImage"];
        cell.leftTextLabel.text = @"一叶小舟";
        
    }else{
        cell.imageV.image = [UIImage imageNamed:[NSString stringWithFormat:@"my%ld",(long)indexPath.row]];
        cell.leftTextLabel.text =[cellLeftTextArray objectAtIndex:indexPath.row];
    }
    
    
    return cell;
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    self.sectionSelect(indexPath.row);
}
- (void)cellClickBlock :(sectionSelectBlock )bolck;
{
    self.sectionSelect = bolck;
}

@end
