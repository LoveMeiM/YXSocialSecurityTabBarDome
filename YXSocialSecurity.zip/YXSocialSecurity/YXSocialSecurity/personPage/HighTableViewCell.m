//
//  HighTableViewCell.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/14.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "HighTableViewCell.h"

@implementation HighTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        
        self.contentView.backgroundColor = litteGray;
        
        UIView *bgView = [[UIView alloc]init];
        bgView.backgroundColor = [UIColor whiteColor];
        [self addSubview:bgView];
        bgView.sd_layout.leftSpaceToView(self,Scale_X(0)).topSpaceToView(self,0).rightSpaceToView(self,Scale_X(0)).bottomSpaceToView(self,0);
        
        
        self.titleLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"感冒灵颗粒二盒" :MEDIUM_FONT :1 :blackC];
        [bgView addSubview:self.titleLabel];
        self.titleLabel.sd_layout
        .leftSpaceToView(bgView,Scale_X(15))
        .topSpaceToView(bgView,Scale_Y(10))
        .widthIs(Scale_X(200))
        .heightIs(Scale_Y(15));
        
        
        self.messageLabel  = [[MethodTool shareTool] creatLabelWithAttribute:@"惠州市东平百姓缘大药房 （编号：08079）" :SMALL_FONT :1 :GrayTextColor];
        [bgView addSubview:self.messageLabel];
        self.messageLabel.sd_layout
        .leftEqualToView(self.titleLabel)
        .topSpaceToView(self.titleLabel,Scale_Y(5))
        .widthIs(Scale_X(300))
        .heightIs(Scale_Y(15));
        
        
        self.timeLabel  = [[MethodTool shareTool] creatLabelWithAttribute:@"2016-08-09" :SMALL_FONT :1 :GrayTextColor];
        [bgView addSubview:self.timeLabel];
        self.timeLabel.sd_layout
        .leftEqualToView(self.titleLabel)
        .topSpaceToView(self.messageLabel,Scale_Y(5))
        .widthIs(Scale_X(200))
        .heightIs(Scale_Y(15));

        
        self.priceLabel  = [[MethodTool shareTool] creatLabelWithAttribute:@"¥ 26.98" :SMALL_FONT :3 :REDCOLOR];
        [bgView addSubview:self.priceLabel];
        self.priceLabel.sd_layout
        .rightSpaceToView(bgView,Scale_X(10))
        .topSpaceToView(bgView,Scale_Y(10))
        .widthIs(Scale_X(80))
        .heightIs(Scale_Y(15));

        
        
        
        //底部的细线
        UIView *lineV = [UIView new];
        [bgView addSubview:lineV];
        lineV.backgroundColor = ViewlineColor;
        lineV.sd_layout
        .leftSpaceToView(bgView,Scale_X(0))
        .bottomSpaceToView(bgView,Scale_Y(0))
        .rightSpaceToView(bgView,Scale_X(0))
        .heightIs(Scale_Y(1));
        
    }
    return self;
}

@end
