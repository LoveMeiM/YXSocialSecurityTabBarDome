//
//  SecondViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PersonViewController.h"
#import "LoginViewController.h"
#import "BaseNavigationController.h"
#import "PersonView.h"
#import "PersonSocialSecurityCardViewController.h"
#import "PersonDiagnosisCardViewController.h"
#import "PersonPayRecordViewController.h"

@interface PersonViewController ()
{
    UITableView *Tb;
    
    NSArray *cellLeftTextArray;
    UIImageView *headHeadBgImageV;
}
@end

@implementation PersonViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"个人中心"];

    
    PersonView *personV = [[PersonView alloc]init];
    [personV initSubVWithSuperView:self.view];
   
    __weak __typeof(self)weakSelf = self;
    [personV cellClickBlock:^(NSInteger sectionIndex) {
        weakSelf.hidesBottomBarWhenPushed = YES;
        switch (sectionIndex) {
        
            case 0:
                break;
            case 1:
               {
                [self.navigationController presentViewController:[[UINavigationController alloc]initWithRootViewController:[[LoginViewController alloc]init]] animated:YES completion:nil];
               }
                break;
            case 2:
                {
                    FOR_PUSH
                  [self.navigationController pushViewController:[[PersonDiagnosisCardViewController alloc]init] animated:YES];
                }
                break;
            case 3:
                {
                FOR_PUSH
                [self.navigationController pushViewController:[[PersonSocialSecurityCardViewController alloc]init] animated:YES];
        
                }
                break;
            case 4:
            {
                FOR_PUSH
                [self.navigationController pushViewController:[[PersonPayRecordViewController alloc]init] animated:YES];
                
            }
                
            default:
                break;
        }
        
        weakSelf.hidesBottomBarWhenPushed = NO;
    }];
    
}
//放里面不会被调用
- (void)initData
{
    ShowHUD
    [[InterNetRequest shareRequest]loginOut:^(NSDictionary *dataDic) {
        DismissHUD
        if (Success) {
            [[MethodTool shareTool] setUserDefaults:@"" :@"sysuserid"];
            BaseNavigationController *baseNav = [[BaseNavigationController alloc]initWithRootViewController:[[LoginViewController alloc]init]];
            [[MethodTool shareTool]  changeWindowRootViewController:baseNav :4];
        }
        
    } :^(NSError *error) {
        DismissHUD
    }];
}



/*
 
 //                  UIAlertAction *suerAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
 //                      [self initData];
 //                  }];
 //                   UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {}];
 //                  UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"确定要退出登录吗" preferredStyle:UIAlertControllerStyleAlert];
 //                   [alertVC addAction:suerAction];
 //                   [alertVC addAction:cancelAction];
 //                   [self presentViewController:alertVC animated:YES completion:nil];
 
 */



@end
