//
//  PersonPayRecordViewController.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/21.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PersonPayRecordViewController.h"
#import "PayRecordTableView.h"
#import "PersonPayRecordDetailViewController.h"

@interface PersonPayRecordViewController ()
{
    PayRecordTableView *PayRecordTb;
    NSArray *leftArray1;
    NSArray *rightArray1;
}
@end


@implementation PersonPayRecordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"支付记录"];
    self.sc.backgroundColor = litteGray;
    
    leftArray1 = [[NSArray alloc]initWithObjects:@"姓名",
                  @"卡号",
                  @"余额",nil];
    
    rightArray1 = [[NSArray alloc]initWithObjects:@"李军洪",
                   @"2423423423432423423",
                   @"¥ 2515",nil];

    
    PayRecordTb = [[PayRecordTableView alloc] initWithFrame:CGRectMake(0, NavHeight+Scale_Y(4), WIDTH, HEIGHT-NavHeight-Scale_Y(50))];
    PayRecordTb.leftArray = leftArray1;
    PayRecordTb.rightArray = rightArray1;
    [self.view addSubview:PayRecordTb];
    
     FOR_PUSH
    __weak typeof(self)weakSelf = self;
    PayRecordTb.cellClick = ^(NSInteger cellIndex)
    {
        [weakSelf.navigationController pushViewController:[[PersonPayRecordDetailViewController alloc]init] animated:YES];
    };
    
}


@end
