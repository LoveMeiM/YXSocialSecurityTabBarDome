//
//  PersonView.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/16.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseView.h"

typedef void(^sectionSelectBlock)(NSInteger sectionIndex);

@interface PersonView : BaseView
<UITableViewDelegate,UITableViewDataSource>
{
    NSArray *cellLeftTextArray;
    UITableView *Tb;
    UIImageView *headHeadBgImageV;
}
@property(copy,nonatomic)sectionSelectBlock sectionSelect;

- (void)cellClickBlock :(sectionSelectBlock )bolck;
- (void)initSubVWithSuperView :(UIView *)superV;


@end
