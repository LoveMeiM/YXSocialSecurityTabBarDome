//
//  PersonPayRecordDetailViewController.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/21.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PersonPayRecordDetailViewController.h"
#import "InformationTableView.h"

@interface PersonPayRecordDetailViewController ()
{
    InformationTableView *informationTb;
    
    NSArray *leftArray1;
    NSArray *rightArray1;
}
@end


@implementation PersonPayRecordDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"支付记录详情"];
    self.sc.backgroundColor = litteGray;
    
    
    leftArray1 = [[NSArray alloc]initWithObjects:
                  @"消费类型",
                  @"账单编号",
                  @"消息时间",
                  @"商户编号",
                  @"终端编号",
                  @"终端流水"
                  @"参考号",
                  @"交易卡号",
                  @"交易金额",
                  @"交易备注",nil];
    
    rightArray1 = [[NSArray alloc]initWithObjects:
                   @"门诊费",
                   @"020021",
                   @"2016-07-21 15:21",
                   @"2120200",
                   @"10835621",
                   @"201607211532"
                   @"0255",
                   @"621627262726272",
                   @"¥ 24.68",
                   @"无",nil];
    
    
    informationTb = [[InformationTableView alloc] initWithFrame:CGRectMake(0,  NavHeight+Scale_Y(10), WIDTH, HEIGHT-NavHeight-Scale_Y(50))];
    informationTb.leftArray = leftArray1;
    informationTb.rightArray = rightArray1;
    [self.view addSubview:informationTb];
    [informationTb setSomeCellRightTextColor:7];
    informationTb.tableHeaderView = [self creatTableViewHeadView];
    
    
}

- (UIView *)creatTableViewHeadView
{
    
    UIView *headV = [[UIView alloc]init];
    headV.backgroundColor = litteGray;
    headV.sd_layout.leftSpaceToView(informationTb,0).topSpaceToView(informationTb,10).rightSpaceToView(informationTb,0).heightIs(Scale_Y(40));
    
    UIView *bgView = [[UIView alloc]init];
    [headV addSubview:bgView];
    bgView.backgroundColor = RGB(250, 250, 250, 1);
    bgView.layer.borderWidth = 0.8;
    bgView.layer.borderColor = ViewlineColor.CGColor;
    bgView.sd_layout.leftSpaceToView(headV,10).topSpaceToView(headV,0).rightSpaceToView(headV,10).heightIs(Scale_Y(40));
    
    
    UILabel *titleLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"支付详情" :SMALL_FONT :2 :blackC];
    [bgView addSubview:titleLabel];
    titleLabel.sd_layout
    .centerXEqualToView(bgView)
    .centerYEqualToView(bgView)
    .widthIs(Scale_X(100))
    .heightIs(Scale_Y(15));
    
    
    //底部的细线
    UIView *lineV = [UIView new];
    [bgView addSubview:lineV];
    lineV.backgroundColor = ViewlineColor;
    lineV.sd_layout
    .leftSpaceToView(bgView,Scale_X(0))
    .bottomSpaceToView(bgView,Scale_Y(0))
    .rightSpaceToView(bgView,Scale_X(0))
    .heightIs(Scale_Y(1));
    
    return headV;
}

@end
