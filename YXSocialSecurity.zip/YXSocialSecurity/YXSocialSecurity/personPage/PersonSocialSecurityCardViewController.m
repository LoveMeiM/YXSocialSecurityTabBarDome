//
//  PersonSocialSecurityCardViewController.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/12.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PersonSocialSecurityCardViewController.h"
#import "HighInformationTableView.h"
#import "HYSegmentedControl.h"
#import "InformationTableView.h"

@interface PersonSocialSecurityCardViewController ()
{
    HYSegmentedControl *SegmentedControl;
    InformationTableView *informationTb;
    HighInformationTableView *HighInformationTb;
    
    NSArray *leftArray1;
    NSArray *rightArray1;
}
@end


@implementation PersonSocialSecurityCardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"社保卡"];
    self.sc.backgroundColor = litteGray;
    
    SegmentedControl = [[HYSegmentedControl alloc]initWithOriginY:CGRectMake(0, NavHeight, WIDTH, Scale_Y(40))
                                                           Titles:@[@"社保卡信息", @"消费纪录"]
                                                                 :blackC
                                                                 :MainNavColor
                                                                 :[UIColor whiteColor]
                                                         delegate:self] ;
    
    [self.view addSubview:SegmentedControl];
    
    
    
    
    leftArray1 = [[NSArray alloc]initWithObjects:@"姓名",
                  @"卡号",
                  @"余额",nil];
    
    rightArray1 = [[NSArray alloc]initWithObjects:@"李军洪",
                   @"2423423423432423423",
                   @"¥ 2515",nil];
    
    
    informationTb = [[InformationTableView alloc] initWithFrame:CGRectMake(0,  NavHeight+Scale_Y(44), WIDTH, HEIGHT-NavHeight-Scale_Y(50))];
    informationTb.leftArray = leftArray1;
    informationTb.rightArray = rightArray1;
    [self.view addSubview:informationTb];
    [informationTb setSomeCellRightTextColor:2];
    informationTb.tableHeaderView = [self creatTableViewHeadView];
    

    HighInformationTb = [[HighInformationTableView alloc] initWithFrame:CGRectMake(0, NavHeight+Scale_Y(44), WIDTH, HEIGHT-NavHeight-Scale_Y(50))];
    HighInformationTb.leftArray = leftArray1;
    HighInformationTb.rightArray = rightArray1;

    
}



#pragma mark－－－－－－－hySegmentedControl delegate－－－－－－－－－



- (void)hySegmentedControlSelectAtIndex:(NSInteger)index
{
    if (index == 0) {
        [HighInformationTb removeFromSuperview];
         [self.view addSubview:informationTb];
    }
    else{
        [informationTb removeFromSuperview];
         [self.view addSubview:HighInformationTb];
    }
}


- (UIView *)creatTableViewHeadView
{
    
    UIView *headV = [[UIView alloc]init];
    headV.backgroundColor = litteGray;
    headV.sd_layout.leftSpaceToView(informationTb,0).topSpaceToView(informationTb,10).rightSpaceToView(informationTb,0).heightIs(Scale_Y(40));
    
    UIView *bgView = [[UIView alloc]init];
    [headV addSubview:bgView];
    bgView.backgroundColor = RGB(250, 250, 250, 1);
    bgView.layer.borderWidth = 0.8;
    bgView.layer.borderColor = ViewlineColor.CGColor;
    bgView.sd_layout.leftSpaceToView(headV,10).topSpaceToView(headV,0).rightSpaceToView(headV,10).heightIs(Scale_Y(40));
    
    
    UILabel *titleLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"社保卡信息" :SMALL_FONT :2 :blackC];
    [bgView addSubview:titleLabel];
    titleLabel.sd_layout
    .centerXEqualToView(bgView)
    .centerYEqualToView(bgView)
    .widthIs(Scale_X(100))
    .heightIs(Scale_Y(15));
    
    
    //底部的细线
    UIView *lineV = [UIView new];
    [bgView addSubview:lineV];
    lineV.backgroundColor = ViewlineColor;
    lineV.sd_layout
    .leftSpaceToView(bgView,Scale_X(0))
    .bottomSpaceToView(bgView,Scale_Y(0))
    .rightSpaceToView(bgView,Scale_X(0))
    .heightIs(Scale_Y(1));
    
    return headV;
}


@end
