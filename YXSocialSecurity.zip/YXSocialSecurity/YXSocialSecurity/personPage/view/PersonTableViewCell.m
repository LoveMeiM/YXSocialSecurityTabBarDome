 //
//  PersonTableViewCell.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/26.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PersonTableViewCell.h"

@implementation PersonTableViewCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        

        self.contentView.backgroundColor = [UIColor whiteColor];
        
        
        //图片
        self.imageV = [[MethodTool shareTool] creatImageWithAttribute:@""];
        [self.contentView addSubview:self.imageV];
        self.imageV.sd_layout
        .leftSpaceToView(self.contentView,Scale_X(15))
        .centerYEqualToView(self.contentView)
        .widthIs(Scale_X(24))
        .heightIs(Scale_Y(24));
        
        
        
        self.leftTextLabel = [[MethodTool shareTool]  creatLabelWithAttribute:@"" :14 :1 :blackC];
        [self.contentView addSubview:self.leftTextLabel];
        self.leftTextLabel.sd_layout
        .leftSpaceToView(self.imageV,Scale_X(15))
        .centerYEqualToView(self.contentView)
        .widthIs(Scale_X(100))
        .heightIs(Scale_X(20));
        

        //底部的细线
        UIView *lineV = [UIView new];
        [self addSubview:lineV];
        lineV.backgroundColor = litteGray;
        lineV.sd_layout
        .leftSpaceToView(self,Scale_X(0))
        .bottomSpaceToView(self,Scale_Y(0))
        .rightSpaceToView(self,Scale_X(0))
        .heightIs(Scale_Y(1));
        
        
    }
    return self;
}


@end
