//
//  PayRecordTableView.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/21.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PayRecordTableView.h"

@implementation PayRecordTableView
/**
 *  支付记录的tableView
 */

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    HighTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[HighTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        UIImageView *imageV = [[MethodTool shareTool]  creatImageWithAttribute:@"personArrow"];
        imageV.bounds = CGRectMake(0, 0, 14, 14);
        cell.accessoryView = imageV;
    }
    cell.priceLabel.hidden = YES;
    cell.timeLabel.textColor = REDCOLOR;
    cell.titleLabel.text = @"水口黄镇江卫生站门诊费";
    cell.messageLabel.text = @"水口黄镇江卫生站 2016-07-12";
    cell.timeLabel.text = @"¥ 24.68";
    
    NSArray *someArray = @[@"22",@"1",@"4",@"43",@"23",@"9"];
    [self caculateArray:someArray];
    
    
    NSArray *array = @[@{@"xixi" : @"cookeee",@"code" : @1},
                       @{@"name": @"jim",@"code" : @2},
                       @{@"name": @"jim",@"code" : @1},
                       @{@"name": @"jbos",@"code" : @1}];
    NSLog(@"HAHA  %@", [array valueForKeyPath:@"name"]);
    
    return cell;
}
- (void)caculateArray:(NSArray *)array{
    int sum = [[array valueForKeyPath:@"@sum.intValue"] intValue];
    int avg = [[array valueForKeyPath:@"@avg.intValue"] intValue];
    int max =[[array valueForKeyPath:@"@max.intValue"] intValue];
    int min =[[array valueForKeyPath:@"@min.intValue"] intValue];
 
    
    NSLog(@"WAWAWA:   %d \n %d \n%d \n%d",sum,avg,max,min);
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    self.cellClick(indexPath.row);
}

@end
