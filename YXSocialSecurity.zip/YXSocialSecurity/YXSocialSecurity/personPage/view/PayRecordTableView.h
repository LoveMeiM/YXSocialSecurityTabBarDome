//
//  PayRecordTableView.h
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/21.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "HighInformationTableView.h"

typedef void(^cellClickBlock)(NSInteger cellIndex);

@interface PayRecordTableView : HighInformationTableView
@property(copy,nonatomic)cellClickBlock cellClick;

@end
