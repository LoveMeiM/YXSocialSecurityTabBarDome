//
//  PersonDiagnosisCardViewController.h
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/18.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface PersonDiagnosisCardViewController : BaseViewController

@end
