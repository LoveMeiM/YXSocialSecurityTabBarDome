//
//  HighTableViewCell.h
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/14.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HighTableViewCell : UITableViewCell

@property(strong,nonatomic) UILabel *titleLabel;
@property(strong,nonatomic) UILabel *messageLabel;
@property(strong,nonatomic) UILabel *timeLabel;
@property(strong,nonatomic) UILabel *priceLabel;

@end
