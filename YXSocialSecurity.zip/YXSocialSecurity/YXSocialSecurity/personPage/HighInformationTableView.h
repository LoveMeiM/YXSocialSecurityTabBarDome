//
//  HighInformationTableView.h
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/14.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HighTableViewCell.h"

@interface HighInformationTableView : UITableView
<UITableViewDelegate,UITableViewDataSource>
{
    NSInteger cellRightTextColorChnage;
}

@property(retain,nonatomic)NSArray *leftArray;
@property(retain,nonatomic)NSArray *rightArray;

@end