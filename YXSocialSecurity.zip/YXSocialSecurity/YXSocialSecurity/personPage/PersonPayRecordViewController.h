//
//  PersonPayRecordViewController.h
//  YXSocialSecurity
//
//  Created by liubaojian on 16/9/21.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface PersonPayRecordViewController : BaseViewController

@end
