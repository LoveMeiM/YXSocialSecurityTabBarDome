//
//  NSString+CodeAndClean.m
//  Mall
//
//  Created by liubaojian on 15/11/4.
//  Copyright © 2015年 liubaojian. All rights reserved.
//

#import "NSString+CodeAndClean.h"

@implementation NSString (CodeAndClean)

/**
 *  汉字编码
 */
-(NSString *)encodeChinese ;
{
    return [self stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
}
/**
 *  汉字解码
 */
-(NSString *)decodeChinese;
{
    return  [self stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
}
//清除空格
-(NSString *)delectEmptyString ;
{
    return [self stringByReplacingOccurrencesOfString:@" " withString:@""];
}
-(id)numberInter;
{
    return nil;
}
//前拼接
- (NSString *)headFormat:(NSString *)headStr;
{
    return [NSString stringWithFormat:@"%@%@",headStr,self];
}
//后拼接
- (NSString *)endFormat:(NSString *)endStr;
{
    return [NSString stringWithFormat:@"%@%@",self,endStr];
}

@end
