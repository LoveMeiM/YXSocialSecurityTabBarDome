//
//  InterNetRequest.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/15.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "InterNetRequest.h"
#import "AFNetworking.h"
#import "MyMD5.h"
#import "NSString+CodeAndClean.h"

@implementation InterNetRequest

+(instancetype)shareRequest;
{
    static InterNetRequest *InterNetRequestClass = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        InterNetRequestClass = [[self alloc] init];
    });
    return InterNetRequestClass;
}
- (void)toLogin :(NSString *)userName :(NSString *)md5PassWord :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    dict[@"faccount"] = userName;
    dict[@"fpassword"] = md5PassWord;
    [self AfNetGetRequest:[HttpHead endFormat:@"/appinfo/userLogin_AppLogin.gx"] :dict :successBolck :failBlock];
}
- (void)loginOut :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
{
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    dict[@"sysuserid"] = [[MethodTool shareTool]  getUserDefaults:@"sysuserid"];
    
    [self AfNetGetRequest:[HttpHead endFormat:@"/appinfo/userQuit_AppLogin.gx"] :dict :successBolck :failBlock];
}
- (void)getOrderList :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock
{
    [self AfNetGetRequest:[HttpHead endFormat:@"/appinfo/queryOrderList_AppIvsomas.gx"] :dataDic :successBolck :failBlock];
}
- (void)getOrderDetails :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
{
    [self AfNetGetRequest:[HttpHead endFormat:@"/appinfo/queryOrderInfo_AppIvsomas.gx"] :dataDic :successBolck :failBlock];
}
- (void)getOrderChart :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
{
    [self AfNetGetRequest:[HttpHead endFormat:@"/appinfo/queryOrderStatistics_AppIvsomas.gx"] :dataDic :successBolck :failBlock];
}
- (void)informationSearch :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
{
    [self AfNetGetRequest:[HttpHead endFormat:@"/appinfo/queryConditionParam_AppIvsomas.gx"] :dataDic :successBolck :failBlock];
}


- (void)AfNetGetRequest :(NSString *)urlStr :(NSDictionary *)parametersDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:urlStr parameters:parametersDic success:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         successBolck((NSDictionary *)responseObject);
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
         failBlock(error);
     }];
}



@end
