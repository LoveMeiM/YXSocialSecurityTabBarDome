//
//  MethodTool.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "MethodTool.h"
#import "UIScrollView+VORefresh.h"

@implementation MethodTool


+ (instancetype)shareTool;
{
    static MethodTool *MethodToolClass = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        MethodToolClass = [[self alloc] init];
    });
    return MethodToolClass;
}

-(void)changeWindowRootViewController :(UIViewController*)vc   :(NSInteger)type;
{
    UIWindow *window = [[[UIApplication sharedApplication]delegate]window];
    
    [window.rootViewController.view removeObserver:[[UIApplication sharedApplication]delegate] forKeyPath:@"transform" context: nil];
    window.rootViewController = vc;
    [window.rootViewController.view addObserver:[[UIApplication sharedApplication]delegate] forKeyPath:@"transform" options:NSKeyValueObservingOptionNew context:nil];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.8];
    switch (type) {
        case 1:
            [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:window cache:YES];
            break;
        case 2:
            [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:window cache:YES];
            break;
        case 3:
            [UIView setAnimationTransition:UIViewAnimationTransitionCurlUp forView:window cache:YES];
            break;
        case 4:
            [UIView setAnimationTransition:UIViewAnimationTransitionCurlDown forView:window cache:YES];
            break;
            
        default:
            break;
    }
    [UIView commitAnimations];
    
}

-(UILabel *)creatLabelWithAttribute :(NSString *)titleText
                               :(NSInteger )font
                               :(NSInteger)textAlignmentNumber
                               :(UIColor *)textColor
{
    UILabel *t = [[UILabel alloc] initWithFrame:CGRectZero];
    t.textColor = textColor;
    switch (textAlignmentNumber) {
        case 1:
            t.textAlignment = NSTextAlignmentLeft;
            break;
        case 2:
            t.textAlignment = NSTextAlignmentCenter;
            break;
        case 3:
            t.textAlignment = NSTextAlignmentRight;
            break;
            
        default:
            break;
    }
    
    t.opaque = YES;
    [t setFont:[UIFont fontWithName:@"Helvetica" size:font]];
    t.text = titleText;
    [t setBackgroundColor:[UIColor clearColor]];
    [t sizeToFit];
    return t;
    
}



- (FDLabelView *)creatAdjustLabelWithAttribute :(NSString *)titleText
                                    :(NSInteger )font
                                    :(UIColor *)textColor
{
    FDLabelView* labelView = [[FDLabelView alloc] initWithFrame:CGRectZero];
    labelView.backgroundColor = [UIColor clearColor];
    labelView.textColor = textColor;
    labelView.font = [UIFont fontWithName:@"Helvetica" size:font];
    labelView.text = titleText;
    labelView.fdTextAlignment = FDTextAlignmentFill;
    labelView.fdAutoFitMode = FDAutoFitModeAutoHeight;
    return labelView;
}

- (UIImageView *)creatImageWithAttribute:(NSString *)imageName
{
    UIImageView *ImageV =[[UIImageView alloc] initWithFrame:CGRectZero];
    if (imageName.length>0) {
        ImageV.image = [UIImage  imageNamed:imageName];
    }
    ImageV.backgroundColor = [UIColor clearColor];
    return ImageV;
}

- (UITextField *)creatTextFeild :(NSString *)placeHolder
{
    UITextField  * amiTextFeild = [[UITextField alloc]initWithFrame:CGRectZero];
    if (SYSTEMIOS7) {
        [amiTextFeild  setTintColor:MainNavColor];
    }
    amiTextFeild.backgroundColor = [UIColor whiteColor];
    amiTextFeild.placeholder = placeHolder;
    [amiTextFeild setValue:[UIFont boldSystemFontOfSize:15] forKeyPath:@"_placeholderLabel.font"];
    [amiTextFeild setValue:RGB(180, 180, 180, 1) forKeyPath:@"_placeholderLabel.textColor"];
    amiTextFeild.textColor = RGB(60, 60, 60, 1);
    amiTextFeild.borderStyle = UITextBorderStyleNone;
    amiTextFeild.returnKeyType = UIReturnKeyDone;

    return amiTextFeild;
}
//button
- (UIButton *)creatButtonWithAttribute :(NSString *)titleText
                                      :(NSInteger )font
                                      :(UIColor *)bgColor
                                      :(UIColor *)textColor
{
    UIButton *button=[[UIButton alloc]initWithFrame:CGRectZero];
    [button setBackgroundColor:bgColor];
    [button setTitle:titleText forState:UIControlStateNormal];
    [button.titleLabel setFont:[UIFont systemFontOfSize:font]];
    [button setTitleColor:textColor forState:UIControlStateNormal];
    return button;
}
- (void)shakeView:(UIView*)viewToShake
{
    CGFloat t =8.0;
    CGAffineTransform translateRight  =CGAffineTransformTranslate(CGAffineTransformIdentity, t,0.0);
    CGAffineTransform translateLeft   =CGAffineTransformTranslate(CGAffineTransformIdentity,-t,0.0);
    
    viewToShake.transform = translateLeft;
    
    [UIView animateWithDuration:0.07 delay:0.0 options:UIViewAnimationOptionAutoreverse|UIViewAnimationOptionRepeat animations:^{
        [UIView setAnimationRepeatCount:2.0];
        viewToShake.transform = translateRight;
    } completion:^(BOOL finished){
        if(finished){
            [UIView animateWithDuration:0.05 delay:0.0 options:UIViewAnimationOptionBeginFromCurrentState animations:^{
                viewToShake.transform =CGAffineTransformIdentity;
            } completion:NULL];
        }
    }];
}
- (void)setUserDefaults :(id)obj :(NSString*)key;
{
    if (!obj) {
        return;
    }
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
    [[NSUserDefaults standardUserDefaults] setObject:obj forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
- (id)getUserDefaults :(NSString*)key;
{
    return [[NSUserDefaults standardUserDefaults]objectForKey:key];
}
- (void)removeOneDefaults :(NSString *)key;
{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
}

- (NSString *) cleanData:(id)value {
    
    if (value == nil || value == NULL)
    {
        return @"";
    }
    if ([value isKindOfClass:[NSNull class]]) {
        
        return @"";
    }
    if ([value isKindOfClass:[NSString class]])
    {
        return [value length]==0?@"":value;
    }
    if ([value isKindOfClass:[NSNumber class]])
    {
        return [[value stringValue] length]==0?@"":[value stringValue];
    }
    return @"";
}




//创造属性字符（截取部分颜色变化）
- (NSMutableAttributedString *)creatAttributedString
                   :(NSString *)textTitle
                   :(UIColor *)cutColor
                   :(NSInteger)beginPoint
                   :(NSInteger)length

{
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:textTitle];
    [str addAttribute:NSForegroundColorAttributeName value:cutColor range:NSMakeRange(beginPoint, length)];
    return  str;
}

-(void)reflash :(UIScrollView *)scrollV;
{
    NSMutableAttributedString *str1 = [[NSMutableAttributedString alloc] initWithString:@"下拉刷新内容"];
    NSMutableAttributedString *str2 = [[NSMutableAttributedString alloc] initWithString:@"下拉刷新内容"];
    NSMutableAttributedString *str3 = [[NSMutableAttributedString alloc] initWithString:@"释放立即刷新"];
    NSMutableAttributedString *str4 = [[NSMutableAttributedString alloc] initWithString:@"刷新中..."];
    [str1 addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(0, str1.length)];
    [str2 addAttribute:NSForegroundColorAttributeName value:[UIColor purpleColor] range:NSMakeRange(0, str2.length)];
    [str3 addAttribute:NSForegroundColorAttributeName value:[UIColor brownColor] range:NSMakeRange(0, str3.length)];
    [str4 addAttribute:NSForegroundColorAttributeName value:[UIColor orangeColor] range:NSMakeRange(0, str4.length)];
    scrollV.topRefresh.refreshTexts = @[str1, str2, str3, str4];
}
//获取某一月的起始日期
-(NSString *)getMonthBeginAndEndWith :(NSString *)startDateStr
{
    
    NSDateFormatter *format=[[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy-MM"];
    NSDate *newDate=[format dateFromString:startDateStr];;
    double interval = 0;
    NSDate *beginDate = nil;
    NSDate *endDate = nil;
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    [calendar setFirstWeekday:2];//设定周一为周首日
    BOOL ok = [calendar rangeOfUnit:NSCalendarUnitMonth startDate:&beginDate interval:&interval forDate:newDate];
    //分别修改为 NSDayCalendarUnit NSWeekCalendarUnit NSYearCalendarUnit
    if (ok) {
        endDate = [beginDate dateByAddingTimeInterval:interval-1];
    }else {
        return @"";
    }
    NSDateFormatter *myDateFormatter = [[NSDateFormatter alloc] init];
    [myDateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *beginString = [myDateFormatter stringFromDate:beginDate];
    NSString *endString = [myDateFormatter stringFromDate:endDate];
    NSString *s = [NSString stringWithFormat:@"%@:%@",beginString,endString];
    return s;
}

- (NSMutableArray *)getSevenDaysFormNow
{
    NSMutableArray *addDateArray = [[NSMutableArray alloc]initWithCapacity:0];
    NSTimeInterval secondsPerDay = -1*24 * 60 * 60;
    NSDate * today = [NSDate date];
    NSDateFormatter *myDateFormatter = [[NSDateFormatter alloc] init];
    [myDateFormatter setDateFormat:@"yyyy-MM-dd"];
    //获取最近一周的日期
    for (int i = 0; i < 7; i ++) {
        NSString *dateString = [myDateFormatter stringFromDate:[today dateByAddingTimeInterval:i * secondsPerDay]];
        //去除多余的0操作
        NSMutableArray *strArray = [NSMutableArray arrayWithArray:[dateString componentsSeparatedByString:@"-"]];
        for (int i = 0; i<strArray.count; i++) {
            if ([strArray[i] hasPrefix:@"0"]) {
                [strArray replaceObjectAtIndex:i withObject:[strArray[i] stringByReplacingOccurrencesOfString:@"0" withString:@""]];
            }
        }
        [addDateArray addObject:[strArray componentsJoinedByString:@"-"]];
    }
    return addDateArray;
}
- (NSMutableArray *)getSevenMonthFormNow;
{
    NSMutableArray *addDateArray = [[NSMutableArray alloc]initWithCapacity:0];
    NSDate * today = [NSDate date];
    NSDateFormatter *myDateFormatter = [[NSDateFormatter alloc] init];
    [myDateFormatter setDateFormat:@"yyyy-MM"];
    NSString *dateString = [myDateFormatter stringFromDate:today];
    NSString *monthStr = [[dateString componentsSeparatedByString:@"-"] lastObject];
    //去除多余的0操作
    if ([monthStr hasPrefix:@"0"]) {
        [monthStr stringByReplacingOccurrencesOfString:@"0" withString:@""];
    }
    int year = [[[dateString componentsSeparatedByString:@"-"] firstObject] intValue];
    int month = [monthStr intValue];
    
    for (int i = 0; i < 7; i ++) {
        
        if (month==0) {
            month = 12;
            year--;
        }
        NSString *dateStr = [NSString stringWithFormat:@"%d-%d-%@",year,month,@"1"];
        [addDateArray addObject:dateStr];
        month = month - 1;
    }
    //给的是最近7个月的第一天   day＝1
    return addDateArray;
}

- (NSString *)getToDayDate
{
    NSDate * today = [NSDate date];
    NSDateFormatter *myDateFormatter = [[NSDateFormatter alloc] init];
    [myDateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *dateString = [myDateFormatter stringFromDate:today];
    return dateString;
}


- (NSString *)stringDisposeWithFloat:(double)floatValue
{
    NSString *str = [NSString stringWithFormat:@"%f",floatValue];
    NSInteger len = str.length;
    for (NSInteger i = 0; i < len; i++)
    {
        if (![str  hasSuffix:@"0"])
            break;
        else
            str = [str substringToIndex:[str length]-1];
    }
    if ([str hasSuffix:@"."])//避免像2.0000这样的被解析成2.    以。。。结尾
    {
        return [str substringToIndex:[str length]-1];//s.substring(0, len - i - 1);
    }
    else
    {
        return str;
    }
    
}
- (NSString *)getOneYearDate;
{
    NSDate * today = [NSDate date];
    NSDateFormatter *myDateFormatter = [[NSDateFormatter alloc] init];
    [myDateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *dateString = [myDateFormatter stringFromDate:today];
    
    int year = [[[dateString componentsSeparatedByString:@"-"] firstObject] intValue];
    int month = [[[dateString componentsSeparatedByString:@"-"] objectAtIndex:1] intValue];
    NSString *newDate = [NSString stringWithFormat:@"%d-%d-%@",year-1,month,@"1"];
    return newDate;
}

- (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size {
    if (!color || size.width <= 0 || size.height <= 0) return nil;
    CGRect rect = CGRectMake(0.0f, 0.0f, size.width, size.height);
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, color.CGColor);
    CGContextFillRect(context, rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

- (UIImageView *)findHairlineImageViewUnder:(UIView *)view {
    if ([view isKindOfClass:UIImageView.class] && view.bounds.size.height <= 1.0) {
        return (UIImageView *)view;
    }
    for (UIView *subview in view.subviews) {
        UIImageView *imageView = [self findHairlineImageViewUnder:subview];
        if (imageView) {
            return imageView;
        }
    }
    return nil;
}



@end
