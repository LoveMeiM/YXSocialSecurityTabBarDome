//
//  UIView+ShowSomething.m
//  BossTreasure
//
//  Created by liubaojian on 16/9/14.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "UIView+ShowSomething.h"

@implementation UIView (ShowSomething)

- (void)showLackDataImage;
{
    //图片
    UIImageView *imageV = [[MethodTool shareTool] creatImageWithAttribute:@"no_message"];
    [self addSubview:imageV];
    imageV.sd_layout
    .centerXEqualToView(self)
    .topSpaceToView(self,Scale_Y(150))
    .widthIs(Scale_X(150))
    .heightIs(Scale_Y(92));
    
    
    UILabel  *messageLabel  = [[MethodTool shareTool] creatLabelWithAttribute:@"无数据" :MEDIUM_FONT :2 :blackC];
    [self addSubview:messageLabel];
    messageLabel.sd_layout
    .centerXEqualToView(self)
    .topSpaceToView(self,Scale_Y(260))
    .widthIs(Scale_X(150))
    .heightIs(Scale_Y(20));
    
}
@end
