//
//  DebtsSearchViewController.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/22.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "MedicalViewController.h"
#import "MedicalTableViewCell.h"

@interface MedicalViewController ()
<UITableViewDelegate,UITableViewDataSource>
{
    UITableView *Tb;
}
@end

@implementation MedicalViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"医疗"];

    
    self.view.backgroundColor = litteGray;
    
    Tb = [[UITableView alloc] initWithFrame:CGRectMake(0, NavHeight, WIDTH, HEIGHT-NavHeight-50) style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor clearColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=YES;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    Tb.showsVerticalScrollIndicator = NO;
    [self.view addSubview:Tb];
    Tb.tableHeaderView = [self creatHeadView];
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return Scale_Y(100);
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return Scale_Y(3.5);
}
- (UIView *)creatHeadView
{
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor = [UIColor whiteColor];
    view1.sd_layout.leftSpaceToView(Tb,20).topSpaceToView(Tb,10).rightSpaceToView(Tb,10).heightIs(Scale_Y(300));
    
    
    //头背景图片
    UIImageView *bgImaeV = [[MethodTool shareTool] creatImageWithAttribute:@"testyiliao"];
    [view1 addSubview:bgImaeV];
    bgImaeV.sd_layout.leftSpaceToView(view1,0).topSpaceToView(view1,0).widthIs(Scale_X(320)).heightIs(Scale_Y(130));
    
    
    NSArray *titleArray = @[@"预约挂号",@"当天挂号",@"门诊缴费",@"检验报告",@"预约检查",@"医保卡"];
    
    for (int i = 0; i<titleArray.count;i++) {
        
        int for_x = i%3;
        int for_y = i/3;
        
        //图片
        UIImageView *bgImaeV = [[MethodTool shareTool] creatImageWithAttribute:[NSString stringWithFormat:@"yiliao%d",i]];
        [view1 addSubview:bgImaeV];
        bgImaeV.sd_layout.leftSpaceToView(view1,Scale_X((28+for_x*108))).topSpaceToView(view1,Scale_Y((140+for_y*75))).widthIs(Scale_X(49)).heightIs(Scale_X(49));
        
        //标题
        UILabel *titlelabel  = [[MethodTool shareTool] creatLabelWithAttribute:[titleArray objectAtIndex:i] :MEDIUM_FONT :2 :blackC];
        [view1 addSubview:titlelabel];
        titlelabel.sd_layout
        .leftSpaceToView(view1,WIDTH/3*for_x)
        .topSpaceToView(bgImaeV,Scale_Y(5))
        .widthIs((WIDTH/3))
        .heightIs(Scale_Y(20));
        
        
        UIButton *but = [[MethodTool shareTool]creatButtonWithAttribute:@"" :11 :[UIColor clearColor] :[UIColor clearColor]];
        [view1 addSubview:but];
        but.tag = 200+i;
        but.sd_layout
        .leftSpaceToView(view1,((0+for_x*WIDTH/3)))
        .topSpaceToView(view1,Scale_Y((130+for_y*80)))
        .widthIs((WIDTH/3))
        .heightIs(Scale_Y(70));
        [but addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    
    
    return view1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    MedicalTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[MedicalTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.tag = indexPath.row;
    cell.imageV.image = [UIImage imageNamed:[NSString stringWithFormat:@"testPeople"]];
    //cell.dataDic = cellDataArray[indexPath.row];
    
    return cell;
}

//选择
- (void)selectButton :(UIButton *)sender
{
    
}


@end
