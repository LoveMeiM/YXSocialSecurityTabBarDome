//
//  DebtsSearchViewController.h
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/22.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface MedicalViewController : BaseViewController


@end
