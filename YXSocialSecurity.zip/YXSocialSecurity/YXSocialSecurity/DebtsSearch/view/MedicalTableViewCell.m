//
//  MedicalTableViewCell.m
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/28.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "MedicalTableViewCell.h"

@implementation MedicalTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        
        //图片
        self.imageV = [[MethodTool shareTool] creatImageWithAttribute:@""];
        [self.contentView addSubview:self.imageV];
        self.imageV.sd_layout
        .leftSpaceToView(self.contentView,Scale_X(10))
        .centerYEqualToView(self.contentView)
        .widthIs(Scale_X(60))
        .heightIs(Scale_X(70));
        
        
        self.nameLabel= [[MethodTool shareTool] creatLabelWithAttribute:@"柳如江" :MEDIUM_FONT :1 :blackC];
        [self.contentView addSubview:self.nameLabel];
        self.nameLabel.sd_layout
        .leftSpaceToView(self.imageV,Scale_X(10))
        .topSpaceToView(self.contentView,Scale_Y(10))
        .widthIs(Scale_X(60))
        .heightIs(Scale_Y(15));
        
        
        self.professionalLabel  = [[MethodTool shareTool] creatLabelWithAttribute:@"医学博士" :SMALL_FONT :1 :GrayTextColor];
        [self.contentView addSubview:self.professionalLabel];
        self.professionalLabel.sd_layout
        .leftSpaceToView(self.nameLabel,Scale_X(0))
        .topSpaceToView(self.contentView,Scale_Y(10))
        .widthIs(Scale_X(60))
        .heightIs(Scale_Y(15));
        
        
        
        self.hospitalLabel  = [[MethodTool shareTool] creatLabelWithAttribute:@"惠州市中心医院" :SMALL_FONT :1 :blueGreenColor];
        [self.contentView addSubview:self.hospitalLabel];
        self.hospitalLabel.sd_layout
        .leftEqualToView(self.nameLabel)
        .topSpaceToView(self.nameLabel,Scale_Y(5))
        .widthIs(Scale_X(120))
        .heightIs(Scale_Y(15));
        
        
        self.describeLabel  = [[MethodTool shareTool] creatLabelWithAttribute:@"2002年毕业于中国协和医院大学并获得医学院博士学位，2002年是实施内科从事临床工作，完成很多大型的手术" :SMALL_FONT :1 :GrayTextColor];
        [self.contentView addSubview:self.describeLabel];
        self.describeLabel.numberOfLines = 2;
        self.describeLabel.sd_layout
        .leftEqualToView(self.nameLabel)
        .bottomSpaceToView(self.contentView,Scale_Y(10))
        .rightSpaceToView(self.contentView,Scale_X(10))
        .heightIs(Scale_Y(40));
        
        
        
        UIButton *but = [[MethodTool shareTool]creatButtonWithAttribute:@"在线咨询" :SMALL_FONT :blueGreenColor :[UIColor whiteColor]];
        [self addSubview:but];
        but.layer.cornerRadius = Scale_X(3);
        but.sd_layout
        .rightSpaceToView(self,Scale_X(15))
        .topEqualToView(self.nameLabel)
        .widthIs((Scale_X(70)))
        .heightIs(Scale_Y(28));
        [but addTarget:self action:@selector(onlineTalk) forControlEvents:UIControlEventTouchUpInside];
        
        
        //底部的细线
        UIView *lineV = [UIView new];
        [self.contentView addSubview:lineV];
        lineV.backgroundColor = litteGray;
        lineV.sd_layout
        .leftSpaceToView(self.contentView,Scale_X(0))
        .bottomSpaceToView(self.contentView,Scale_Y(0))
        .rightSpaceToView(self.contentView,Scale_X(0))
        .heightIs(Scale_X(0.8));
        
    }
    return self;
}

//在线咨询
- (void)onlineTalk
{
    
}

@end
