//
//  MedicalTableViewCell.h
//  YXSocialSecurity
//
//  Created by liubaojian on 16/8/28.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MedicalTableViewCell : UITableViewCell
@property(strong,nonatomic)UIImageView *imageV ;
@property(strong,nonatomic)UILabel *nameLabel;
@property(strong,nonatomic)UILabel *professionalLabel;
@property(strong,nonatomic)UILabel *hospitalLabel;
@property(strong,nonatomic)UILabel *describeLabel;
@end
