//
//  LoginView.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/13.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "LoginView.h"

@implementation LoginView

- (instancetype)init
{
    self = [super init];
    if (self) {
        rememberPW = [[[MethodTool shareTool]  getUserDefaults:@"rememberPW"] boolValue];
        userName = [[MethodTool shareTool]  getUserDefaults:@"UserName"];
        passWord = [[MethodTool shareTool]  getUserDefaults:@"PassWord"];
        [self initSub];
    }
    return self;
}

- (void)initSub
{

    nameBgView = [UIView new];
    nameBgView.backgroundColor = [UIColor whiteColor];
    [self addSubview:nameBgView];
    nameBgView.sd_layout.leftSpaceToView(self,Scale_X(15)).topSpaceToView(self,Scale_Y(20)).rightSpaceToView(self,Scale_X(15)).heightIs(Scale_Y(40));
    
    
    nameTF = [[MethodTool shareTool]  creatTextFeild:@"用户名"];
    [nameBgView addSubview:nameTF];
    nameTF.delegate = self;
    UIEdgeInsets sg = UIEdgeInsetsMake(10, 15, 10, 15);
    nameTF.sd_layout.spaceToSuperView(sg);
    //用户名
    if ([userName length]>0) {
        nameTF.text = userName;
    }
    
    
    passWordBgView = [UIView new];
    passWordBgView.backgroundColor = [UIColor whiteColor];
    [self addSubview:passWordBgView];
    passWordBgView.sd_layout.leftEqualToView(nameBgView).topSpaceToView(nameBgView,Scale_Y(15)).rightEqualToView(nameBgView).heightRatioToView(nameBgView,1);
    
    passWordTF = [[MethodTool shareTool]  creatTextFeild:@"密码"];
    [passWordBgView addSubview:passWordTF];
    passWordTF.secureTextEntry = YES;
    passWordTF.delegate = self;
    UIEdgeInsets sg1 = UIEdgeInsetsMake(10, 15, 10, 15);
    passWordTF.sd_layout.spaceToSuperView(sg1);
    //记住密码
    if ([passWord length]>0) {
        passWordTF.text = @"abcde";
    }
    
    //记住密码
    
    UIButton *rememberB = [UIButton new];
    [self addSubview:rememberB];
    rememberB.selected = rememberPW;
    rememberB.sd_layout.leftEqualToView(passWordBgView).topSpaceToView(passWordBgView,0).widthIs(Scale_X(50)).heightIs(Scale_Y(40));
    [rememberB addTarget:self action:@selector(rememberClick:) forControlEvents:UIControlEventTouchUpInside];
    
    rememberPassWordImageV = [[MethodTool shareTool]  creatImageWithAttribute:rememberPW?@"loginSelect":@"onSelectKuang"];
    [self addSubview:rememberPassWordImageV];
    rememberPassWordImageV.sd_layout.leftSpaceToView(self,Scale_X(17)).topSpaceToView(passWordBgView,Scale_Y(7)).widthIs(Scale_X(25)).heightIs(Scale_X(25));
    
    UILabel *rememberLabel = [[MethodTool shareTool]  creatLabelWithAttribute:@"记住密码" :MEDIUM_FONT :1 :blackC];
    [self addSubview:rememberLabel];
    rememberLabel.sd_layout.leftSpaceToView(rememberPassWordImageV,Scale_X(5)).topSpaceToView(passWordBgView,Scale_Y(13)).widthIs(Scale_X(80)).heightIs(Scale_Y(15));
    
    //自动登录
    UILabel *autoLoginLabel = [[MethodTool shareTool]  creatLabelWithAttribute:@"忘记密码？" :MEDIUM_FONT :3 :GrayTextColor];
    [self addSubview:autoLoginLabel];
    autoLoginLabel.sd_layout.rightEqualToView(passWordBgView).topSpaceToView(passWordBgView,Scale_Y(13)).widthIs(Scale_X(80)).heightIs(Scale_Y(15));
    

    UIButton *aotuLoginB = [UIButton new];
    [self addSubview:aotuLoginB];
    aotuLoginB.sd_layout.rightEqualToView(passWordBgView).topEqualToView(rememberPassWordImageV).widthIs(Scale_X(80)).heightIs(Scale_Y(15));
    [aotuLoginB addTarget:self action:@selector(forgetPassWord) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIButton *loginButton = [[MethodTool shareTool]  creatButtonWithAttribute:@"登录" :MEDIUM_FONT+2 :MainNavColor :[UIColor whiteColor]];
    [self addSubview:loginButton];
    loginButton.sd_layout.leftEqualToView(passWordBgView).topSpaceToView(passWordBgView,Scale_Y(80)).rightEqualToView(passWordBgView).heightIs(Scale_Y(40));
    loginButton.layer.cornerRadius = 3;
    [loginButton addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
    
}

#pragma mark－－－－－－－－－－－－－－－－－－－事件－－－－－－－－－－－－－－－－
//记住密码
-(void)rememberClick :(UIButton *)sender
{
    sender.selected = !sender.selected;
    if (sender.selected) {
        rememberPassWordImageV.image = [UIImage imageNamed:@"loginSelect"];\
        rememberPW = YES;
    } else {
        rememberPassWordImageV.image = [UIImage imageNamed:@"onSelectKuang"];
        rememberPW = NO;
        [[MethodTool shareTool]  setUserDefaults:@"" :@"PassWord"];
    }
    [[MethodTool shareTool]  setUserDefaults:[NSNumber numberWithBool:rememberPW] :@"rememberPW"];
}

//登录
-(void)login
{
    if (nameTF.text.length==0) {
        showMessage(@"请输入用户名");
    }//限制输入的密码长度小于32位（md5 值）更安全，
    else if (passWordTF.text.length == 0||passWordTF.text.length >10){
        showMessage(@"密码输入有误");
    }
    else
    {
        NSArray *array = @[];
        if (passWord.length==32) {
            array = @[nameTF.text,passWord];
        }else{
            array = @[nameTF.text,passWordTF.text];
        }
        self.block(array);
    }
    
}
// 忘记密码
-(void)forgetPassWord
{
    self.forgetPWBlock();
}

- (void)dologin :(loginBlock)block
{
    self.block = block;
}
-(void)forgetPassWordClick:(forgetPassWordBlock)block
{
    self.forgetPWBlock = block;
}


@end
