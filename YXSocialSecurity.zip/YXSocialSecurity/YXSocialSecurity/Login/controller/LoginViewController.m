//
//  LoginViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/13.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "LoginViewController.h"
#import "LoginView.h"
#import "MainTabBarViewController.h"
#import "MyMD5.h"


extern  NSString *UserId;
@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    [super creatLoginView];
    
    self.sc.backgroundColor = litteGray;
    LoginView *loginV = [[LoginView alloc]init];
    loginV.frame = self.view.frame;
    [self.sc addSubview:loginV];
    [self.view bringSubviewToFront:self.sc];
    
    //登录
    [loginV dologin:^(NSArray *parameterArray) {

        //传过来的数据是否是md5加密的
        NSString *md5PassWord  = @"";
        if ([parameterArray[1] length]<=20) {
            md5PassWord = [MyMD5 md5:parameterArray[1]];
        }else{
            md5PassWord = parameterArray[1];
        }
        
        ShowHUD
        [[InterNetRequest shareRequest]toLogin:parameterArray[0] :md5PassWord :^(NSDictionary *dataDic) {
            NSLog(@"kkkk:%@",dataDic);
            DismissHUD
            if (Success) {
                //记住密码
                if ([[[MethodTool shareTool] getUserDefaults:@"rememberPW"] boolValue]) {
                    [[MethodTool shareTool] setUserDefaults:parameterArray[0] :@"UserName"];
                    [[MethodTool shareTool] setUserDefaults:md5PassWord :@"PassWord"];
                }
                [[MethodTool shareTool] setUserDefaults:dataDic[@"data"][@"sysuserid"] :@"sysuserid"];
                [[MethodTool shareTool] setUserDefaults:dataDic[@"data"][@"unionNo"] :@"unionNo"];
                //全局UserId
                UserId = dataDic[@"data"][@"sysuserid"];
                MainTabBarViewController *rotVC = [[MainTabBarViewController alloc]init];
                [[MethodTool shareTool] changeWindowRootViewController:rotVC :3];
            }
        } :^(NSError *error) {
            DismissHUD
        }];
    }];
    //设置
    [loginV forgetPassWordClick:^{
        
    }];
        
    
    
}
//首页消失
- (void)dissmissLoginV
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
//设置
-(void)toRegister
{
    FOR_PUSH
   // [self.navigationController pushViewController:[[SettingViewController alloc]init] animated:YES];
    
}



@end
